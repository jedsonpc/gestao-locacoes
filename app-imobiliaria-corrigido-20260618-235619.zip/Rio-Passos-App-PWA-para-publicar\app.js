﻿const storageKey = "gestao-locacoes-v1";
const authKey = "gestao-locacoes-auth-v1";
const sessionKey = "gestao-locacoes-session-v1";
const sessionUserKey = "gestao-locacoes-session-user-v1";
const reminderSessionKey = "gestao-locacoes-contract-reminder-v1";
const syncKey = "gestao-locacoes-sync-v1";
const companyName = "Imobiliaria Rio dos Passos Ltda";
const appStorage = createSafeStorage("app");
const appSessionStorage = createSafeStorage("session");

const initialState = {
  properties: [],
  clients: [],
  contracts: [],
  expenses: [],
  payments: [],
  auditLogs: [],
};

let state = loadState(); // estado inicial do cache local (sincroniza com Supabase no boot)
let syncConfig = loadSyncConfig();
let reportMode = "analytic";

const roleLabels = {
  admin: "Administrador",
  financeiro: "Financeiro",
  operacional: "Operacional",
  consulta: "Consulta",
};

const rolePermissions = {
  admin: ["*"],
  financeiro: ["view", "financial:write", "reports:view"],
  operacional: ["view", "operations:write", "reports:view"],
  consulta: ["view", "reports:view"],
};

const collectionPermissions = {
  properties: "operations:write",
  clients: "operations:write",
  contracts: "operations:write",
  expenses: "financial:write",
  payments: "financial:write",
};

const moneyFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const dateFormatter = new Intl.DateTimeFormat("pt-BR", {
  timeZone: "UTC",
});

const viewTitles = {
  dashboard: "Painel",
  properties: "Imoveis",
  clients: "Clientes",
  contracts: "Contratos",
  expenses: "Despesas",
  payments: "Pagamentos",
  "financial-erp": "ERP financeiro",
  reports: "Relatorios",
  settings: "Acesso e nuvem",
};

const chargeRules = [
  {
    key: "condoFeeResponsible",
    label: "Taxa de condominio",
    kind: "monthly",
    day: 5,
    baseLabel: "Dia 05 de cada mes",
  },
  {
    key: "iptuResponsible",
    label: "IPTU",
    kind: "annual",
    month: 1,
    day: 10,
    baseLabel: "10/02",
  },
  {
    key: "spuResponsible",
    label: "SPU",
    kind: "annual",
    month: 5,
    day: 30,
    baseLabel: "30/06",
  },
  {
    key: "fireFeeResponsible",
    label: "Taxa de bombeiros",
    kind: "annual",
    month: 7,
    day: 31,
    baseLabel: "31/08",
  },
];

async function resolveSupabaseUser(retries = 5, delayMs = 250) {
  for (let attempt = 0; attempt < retries; attempt += 1) {
    const user = await window.SupabaseSync.getCurrentUser();
    if (user) return user;
    await new Promise((resolve) => setTimeout(resolve, delayMs));
  }
  return null;
}

document.addEventListener("DOMContentLoaded", async () => {
  if (!window.SupabaseSync) {
    location.replace("login.html");
    return;
  }

  const user = await resolveSupabaseUser();
  if (!user) {
    location.replace("login.html");
    return;
  }
  activateSupabaseSession(user);

  await reconcileCloudState();

  window.SupabaseSync.subscribeChanges((newData) => {
    state = sanitizeRemoteState(newData);
    saveLocalState(state);
    renderAll();
  });

  await initializeAuth();
  bindNavigation();
  bindForms();
  bindUtilities();
  bindTableActions();
  renderAll();
});

function createSafeStorage(kind) {
  const fallback = new Map();
  try {
    const nativeStorage = kind === "session" ? globalThis.sessionStorage : globalThis.localStorage;
    const testKey = `storage-test-${Date.now()}`;
    nativeStorage.setItem(testKey, "1");
    nativeStorage.removeItem(testKey);
    return nativeStorage;
  } catch {
    return {
      getItem: (key) => (fallback.has(key) ? fallback.get(key) : null),
      setItem: (key, value) => fallback.set(key, String(value)),
      removeItem: (key) => fallback.delete(key),
    };
  }
}

function loadState() {
  const stored = appStorage.getItem(storageKey);
  if (!stored) return structuredClone(initialState);

  try {
    return { ...structuredClone(initialState), ...JSON.parse(stored) };
  } catch {
    return structuredClone(initialState);
  }
}

function saveLocalState(nextState = state) {
  appStorage.setItem(storageKey, JSON.stringify(nextState));
}

function saveState() {
  try {
    saveLocalState(state);
  } catch (error) {
    console.error("Falha ao salvar dados localmente:", error);
  }

  // Salva no Supabase (debounce 300ms) + cache local
  if (window.SupabaseSync) {
    window.SupabaseSync.saveRemoteState(state);
    return true;
  }
  // Fallback se Supabase nao estiver configurado
  try {
    saveLocalState(state);
    return true;
  } catch (error) {
    console.error("Falha ao salvar dados localmente:", error);
    try {
      alert(
        "Nao foi possivel salvar os dados neste navegador.\n" +
        "Causa provavel: armazenamento cheio ou navegacao privada.\n" +
        "Detalhe tecnico: " + (error && error.message ? error.message : error)
      );
    } catch {
      console.warn("Nao foi possivel exibir o alerta de falha de armazenamento.");
    }
    return false;
  }
}

async function reconcileCloudState() {
  const localState = sanitizeRemoteState(state);
  const remote = await window.SupabaseSync.loadRemoteState({ fallbackToCache: false });

  if (!remote) {
    if (hasBusinessData(localState)) {
      state = localState;
      window.SupabaseSync.saveRemoteState(state);
    }
    return;
  }

  const remoteState = sanitizeRemoteState(remote);
  if (shouldPreferLocalState(localState, remoteState)) {
    state = localState;
    window.SupabaseSync.saveRemoteState(state);
    return;
  }

  state = remoteState;
  saveLocalState(state);
}

function hasBusinessData(nextState) {
  return ["properties", "clients", "contracts", "expenses", "payments"].some(
    (collection) => Array.isArray(nextState[collection]) && nextState[collection].length > 0
  );
}

function shouldPreferLocalState(localState, remoteState) {
  const localProperties = localState.properties.length;
  const remoteProperties = remoteState.properties.length;
  if (localProperties > remoteProperties) return true;
  if (remoteProperties > localProperties) return false;
  return countBusinessRecords(localState) > countBusinessRecords(remoteState);
}

function countBusinessRecords(nextState) {
  return ["properties", "clients", "contracts", "expenses", "payments"].reduce(
    (total, collection) => total + (Array.isArray(nextState[collection]) ? nextState[collection].length : 0),
    0
  );
}

function loadSyncConfig() {
  try {
    return JSON.parse(appStorage.getItem(syncKey)) || { endpoint: "", token: "" };
  } catch {
    return { endpoint: "", token: "" };
  }
}

function saveSyncConfig() {
  appStorage.setItem(syncKey, JSON.stringify(syncConfig));
}

async function initializeAuth() {
  saveAuthUsers(await migrateAccessUsers(getStoredAccessUsers()));

  if (appSessionStorage.getItem(sessionKey) === "active" && !getCurrentUser()) {
    appSessionStorage.removeItem(sessionKey);
  }
  document.body.classList.toggle("locked", appSessionStorage.getItem(sessionKey) !== "active");
  const syncForm = document.getElementById("sync-form");
  if (syncForm) {
    syncForm.elements.endpoint.value = syncConfig.endpoint || "";
    syncForm.elements.token.value = syncConfig.token || "";
  }
  const accessForm = document.getElementById("access-form");
  if (accessForm) {
    accessForm.reset();
    accessForm.elements.id.value = "";
  }
  updateSyncStatus();
}

function getStoredAccessUsers() {
  try {
    const stored = JSON.parse(appStorage.getItem(authKey));
    if (Array.isArray(stored?.users) && stored.users.length) {
      return stored.users.map(normalizeAccessUser);
    }
    if (stored?.username && stored?.password) {
      return [normalizeAccessUser(stored)];
    }
  } catch {
    return getDefaultAccessUsers();
  }
  return getDefaultAccessUsers();
}

function getDefaultAccessUsers() {
  return [{ id: uid("user"), username: "admin", password: encodeCredential("admin123"), role: "admin", updatedAt: new Date().toISOString() }];
}

function normalizeAccessUser(user) {
  return {
    id: user.id || uid("user"),
    username: String(user.username || "admin").trim(),
    role: user.role && roleLabels[user.role] ? user.role : "admin",
    password: user.passwordHash ? undefined : user.password || encodeCredential("admin123"),
    passwordHash: user.passwordHash || "",
    salt: user.salt || "",
    hashAlgorithm: user.passwordHash ? user.hashAlgorithm || "SHA-256" : "",
    updatedAt: user.updatedAt || new Date().toISOString(),
  };
}

function saveAuthUsers(users) {
  appStorage.setItem(authKey, JSON.stringify({ users: users.map(normalizeAccessUser) }));
}

function encodeCredential(value) {
  return btoa(unescape(encodeURIComponent(String(value))));
}

async function migrateAccessUsers(users) {
  const migrated = [];
  for (const user of users) {
    if (user.passwordHash && user.salt) {
      migrated.push(normalizeAccessUser(user));
      continue;
    }
    migrated.push({
      ...normalizeAccessUser(user),
      ...(await createPasswordHashFromLegacy(user.password || encodeCredential("admin123"))),
      password: undefined,
    });
  }
  return migrated;
}

async function createPasswordHashFromLegacy(encodedPassword) {
  try {
    return createPasswordHash(decodeURIComponent(escape(atob(encodedPassword))));
  } catch {
    return createPasswordHash("admin123");
  }
}

async function createPasswordHash(password) {
  const saltBytes = crypto.getRandomValues(new Uint8Array(16));
  const salt = bytesToBase64(saltBytes);
  const hash = await digestPassword(password, salt);
  return { passwordHash: hash, salt, hashAlgorithm: "SHA-256" };
}

async function verifyPassword(password, user) {
  if (user.passwordHash && user.salt) {
    return digestPassword(password, user.salt).then((hash) => hash === user.passwordHash);
  }
  return encodeCredential(password) === user.password;
}

async function digestPassword(password, salt) {
  const payload = new TextEncoder().encode(`${salt}:${password}`);
  const hashBuffer = await crypto.subtle.digest("SHA-256", payload);
  return bytesToBase64(new Uint8Array(hashBuffer));
}

function bytesToBase64(bytes) {
  return btoa(String.fromCharCode(...bytes));
}

function uid(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function bindNavigation() {
  document.querySelectorAll(".nav-button").forEach((button) => {
    button.addEventListener("click", () => {
      const target = button.dataset.view;
      if (!canAccessView(target)) {
        alert("Seu perfil nao tem permissao para acessar esta area.");
        return;
      }
      document.querySelectorAll(".nav-button").forEach((item) => item.classList.remove("active"));
      document.querySelectorAll(".view").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      document.getElementById(target).classList.add("active");
      document.getElementById("view-title").textContent = viewTitles[target];
      renderAll();
    });
  });
}

function bindForms() {
  document.getElementById("login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await login(event.currentTarget);
  });

  document.getElementById("property-form").addEventListener("submit", (event) => {
    event.preventDefault();
    upsertFromForm(event.currentTarget, "properties", "property", normalizeProperty);
  });

  document.getElementById("client-form").addEventListener("submit", (event) => {
    event.preventDefault();
    upsertFromForm(event.currentTarget, "clients", "client");
  });

  document.getElementById("contract-form").addEventListener("submit", (event) => {
    event.preventDefault();
    upsertFromForm(event.currentTarget, "contracts", "contract", normalizeContract);
  });

  document.getElementById("expense-form").addEventListener("submit", (event) => {
    event.preventDefault();
    upsertFromForm(event.currentTarget, "expenses", "expense", normalizeExpense);
  });

  const paymentForm = document.getElementById("payment-form");
  paymentForm.addEventListener("submit", (event) => {
    event.preventDefault();
    updatePaymentTotal(paymentForm);
    const contract = updatePaymentContractInfo(paymentForm);
    if (!contract) {
      alert("Para lancar receita, selecione um imovel com contrato vinculado.");
      return;
    }
    upsertFromForm(event.currentTarget, "payments", "payment", normalizePayment);
  });
  ["amount", "chargeAmount"].forEach((name) => {
    paymentForm.elements[name].addEventListener("input", () => updatePaymentTotal(paymentForm));
  });
  ["propertyId", "paymentDate"].forEach((name) => {
    paymentForm.elements[name].addEventListener("change", () => updatePaymentContractInfo(paymentForm));
  });

  document.querySelectorAll("[data-reset]").forEach((button) => {
    button.addEventListener("click", () => {
      document.getElementById(button.dataset.reset).reset();
      document.getElementById(button.dataset.reset).elements.id.value = "";
      if (button.dataset.reset === "payment-form") {
        updatePaymentTotal(document.getElementById("payment-form"));
        updatePaymentContractInfo(document.getElementById("payment-form"));
      }
    });
  });

  document.getElementById("access-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await updateAccess(event.currentTarget);
  });

  document.getElementById("sync-form").addEventListener("submit", (event) => {
    event.preventDefault();
    updateSyncConfig(event.currentTarget);
  });

  ["report-property", "report-client", "report-status", "report-expense-type", "report-start", "report-end", "report-min-value", "report-max-value"].forEach((id) => {
    document.getElementById(id).addEventListener("input", renderReports);
    document.getElementById(id).addEventListener("change", renderReports);
  });

  ["erp-start", "erp-end"].forEach((id) => {
    document.getElementById(id).addEventListener("input", renderFinancialErp);
    document.getElementById(id).addEventListener("change", renderFinancialErp);
  });

  document.querySelectorAll("[data-report-mode]").forEach((button) => {
    button.addEventListener("click", () => {
      reportMode = button.dataset.reportMode;
      document.querySelectorAll("[data-report-mode]").forEach((item) => item.classList.toggle("active", item === button));
      renderReports();
    });
  });
}

function bindUtilities() {
  document.getElementById("seed-data").addEventListener("click", () => {
    state = createSampleData();
    saveState();
    renderAll();
  });

  document.getElementById("clear-data").addEventListener("click", () => {
    if (!requirePermission("admin:write", "Apenas administradores podem limpar os dados.")) return;
    if (!confirm("Deseja apagar todos os dados cadastrados neste navegador?")) return;
    state = structuredClone(initialState);
    addAuditLog("data_cleared", "system", "", null, { message: "Base local limpa pelo usuario." }, false);
    saveState();
    renderAll();
  });

  document.getElementById("export-csv").addEventListener("click", exportReportsCsv);
  document.getElementById("erp-export-pdf")?.addEventListener("click", exportFinancialErpPdf);
  document.getElementById("erp-export-excel")?.addEventListener("click", exportFinancialErpExcel);
  document.getElementById("erp-export-csv")?.addEventListener("click", exportFinancialErpCsv);
  document.getElementById("export-excel").addEventListener("click", exportReportsExcel);
  document.getElementById("export-pdf").addEventListener("click", exportReportsPdf);
  document.getElementById("open-property-document").addEventListener("click", openPropertyDocumentFromForm);
  document.getElementById("logout").addEventListener("click", logout);
  document.getElementById("sync-download").addEventListener("click", downloadFromCloud);
  document.getElementById("sync-upload").addEventListener("click", uploadToCloud);
}

function openPropertyDocumentFromForm() {
  const form = document.getElementById("property-form");
  const link = form.elements.documentLink.value.trim();
  if (!link) {
    alert("Informe o link da documentacao do imovel no Google Drive.");
    return;
  }
  try {
    const url = new URL(link);
    window.open(url.href, "_blank", "noopener");
  } catch {
    alert("Informe um link valido para abrir a documentacao.");
  }
}

async function login(form) {
  const users = getStoredAccessUsers();
  const data = Object.fromEntries(new FormData(form).entries());
  const user = users.find((item) => data.username.trim() === item.username);
  const validAccess = user ? await verifyPassword(data.password, user) : false;

  if (!validAccess) {
    addAuditLog("login_failed", "auth", "", null, { username: data.username.trim() }, false);
    setText("login-message", "Usuario ou senha invalidos.");
    return;
  }

  if (!user.passwordHash || !user.salt) {
    Object.assign(user, await createPasswordHash(data.password), { password: undefined });
    saveAuthUsers(users);
  }

  appSessionStorage.setItem(sessionKey, "active");
  appSessionStorage.setItem(sessionUserKey, JSON.stringify({ id: user.id, username: user.username, role: user.role || "admin" }));
  document.body.classList.remove("locked");
  addAuditLog("login_success", "auth", user.id, null, { username: user.username, role: user.role }, false);
  form.reset();
  setText("login-message", "");
  renderAll();
}

async function logout() {
  const user = getCurrentUser();
  if (user) addAuditLog("logout", "auth", user.id, null, { username: user.username }, false);
  if (window.SupabaseSync) await window.SupabaseSync.signOut();
  appSessionStorage.removeItem(sessionKey);
  appSessionStorage.removeItem(sessionUserKey);
  if (window.SupabaseSync) {
    location.replace("login.html");
    return;
  }
  document.body.classList.add("locked");
}

function activateSupabaseSession(user) {
  const email = user.email || "usuario@supabase";
  appSessionStorage.setItem(sessionKey, "active");
  appSessionStorage.setItem(sessionUserKey, JSON.stringify({
    id: user.id,
    username: email,
    role: "admin",
  }));
}

async function updateAccess(form) {
  if (!requirePermission("admin:write", "Apenas administradores podem gerenciar usuarios.")) return;
  const data = Object.fromEntries(new FormData(form).entries());
  const username = data.username.trim();
  const password = data.password.trim();
  const role = data.role || "consulta";
  const users = getStoredAccessUsers();
  const existingIndex = users.findIndex((user) => user.id === data.id);
  const duplicate = users.some((user) => user.username.toLowerCase() === username.toLowerCase() && user.id !== data.id);

  if (duplicate) {
    setText("settings-message", "Ja existe um usuario com este nome.");
    return;
  }
  if (!data.id && !password) {
    setText("settings-message", "Informe uma senha para cadastrar o usuario.");
    return;
  }
  if (password && password.length < 6) {
    setText("settings-message", "A senha deve ter pelo menos 6 caracteres.");
    return;
  }

  const user = {
    id: data.id || uid("user"),
    username,
    role,
    ...(password ? await createPasswordHash(password) : {
      passwordHash: users[existingIndex]?.passwordHash,
      salt: users[existingIndex]?.salt,
      hashAlgorithm: users[existingIndex]?.hashAlgorithm || "SHA-256",
    }),
    updatedAt: new Date().toISOString(),
  };
  const before = existingIndex >= 0 ? users[existingIndex] : null;

  if (existingIndex >= 0) {
    users[existingIndex] = user;
  } else {
    users.push(user);
  }

  saveAuthUsers(users);
  addAuditLog(existingIndex >= 0 ? "user_updated" : "user_created", "users", user.id, summarizeUser(before), summarizeUser(user), false);
  form.reset();
  form.elements.id.value = "";
  renderAccessUsers();
  setText("settings-message", "Usuario de acesso salvo.");
}

function updateSyncConfig(form) {
  if (!requirePermission("admin:write", "Apenas administradores podem alterar a sincronizacao.")) return;
  const data = Object.fromEntries(new FormData(form).entries());
  syncConfig = {
    endpoint: data.endpoint.trim(),
    token: data.token.trim(),
  };
  saveSyncConfig();
  updateSyncStatus();
  setText("settings-message", syncConfig.endpoint ? "Configuracao de nuvem salva." : "Sincronizacao online desativada.");
}

function upsertFromForm(form, collectionName, prefix, normalizer = (value) => value) {
  if (!canWriteCollection(collectionName)) {
    setText("settings-message", "Seu perfil nao permite alterar este cadastro.");
    alert("Seu perfil nao permite alterar este cadastro.");
    return;
  }
  const data = Object.fromEntries(new FormData(form).entries());
  let record;
  try {
    record = normalizer({
      ...data,
      id: data.id || uid(prefix),
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    alert(error.message || "Nao foi possivel salvar o registro.");
    return;
  }

  const index = state[collectionName].findIndex((item) => item.id === record.id);
  const before = index >= 0 ? state[collectionName][index] : null;
  if (index >= 0) {
    state[collectionName][index] = record;
  } else {
    state[collectionName].push(record);
  }

  addAuditLog(index >= 0 ? "record_updated" : "record_created", collectionName, record.id, before, record, isFinancialCollection(collectionName));
  saveState();
  form.reset();
  form.elements.id.value = "";
  renderAll();
}

function normalizeProperty(record) {
  return {
    ...record,
    description: String(record.description || "").trim(),
    type: String(record.type || "").trim(),
    area: String(record.area || "").trim(),
    location: String(record.location || "").trim(),
    documentLink: String(record.documentLink || "").trim(),
    investmentValue: record.investmentValue === "" || record.investmentValue == null
      ? 0
      : Number(record.investmentValue) || 0,
  };
}

function normalizeContract(record) {
  return {
    ...record,
    monthlyValue: Number(record.monthlyValue || 0),
    dueDay: Number(record.dueDay || 1),
    condoFeeResponsible: record.condoFeeResponsible || "cliente",
    iptuResponsible: record.iptuResponsible || "cliente",
    spuResponsible: record.spuResponsible || "cliente",
    fireFeeResponsible: record.fireFeeResponsible || "cliente",
  };
}

function normalizeExpense(record) {
  return {
    ...record,
    amount: Number(record.amount || 0),
  };
}

function normalizePayment(record) {
  const amount = Number(record.amount || 0);
  const chargeAmount = Number(record.chargeAmount || 0);
  const contract = findPaymentContract(record.propertyId, record.paymentDate, record.contractId);
  const client = findClient(contract?.clientId);
  return {
    ...record,
    contractId: contract?.id || "",
    contractCode: contract ? getContractCode(contract) : "",
    lessorName: client?.name || "",
    amount,
    chargeAmount,
    totalAmount: amount + chargeAmount,
    history: String(record.history || "").trim(),
  };
}

function updatePaymentTotal(form = document.getElementById("payment-form")) {
  const amount = Number(form.elements.amount.value || 0);
  const chargeAmount = Number(form.elements.chargeAmount.value || 0);
  form.elements.totalAmount.value = (amount + chargeAmount).toFixed(2);
}

function updatePaymentContractInfo(form = document.getElementById("payment-form")) {
  if (!form) return null;
  const contract = findPaymentContract(form.elements.propertyId.value, form.elements.paymentDate.value, form.elements.contractId.value);
  const client = findClient(contract?.clientId);

  form.elements.contractId.value = contract?.id || "";
  form.elements.contractCode.value = contract ? getContractCode(contract) : "";
  form.elements.lessorName.value = client?.name || "";
  return contract || null;
}

async function downloadFromCloud() {
  if (!requirePermission("admin:write", "Apenas administradores podem baixar dados da nuvem.")) return;
  if (window.SupabaseSync) {
    setText("settings-message", "Baixando dados do Supabase...");
    try {
      const remote = await window.SupabaseSync.loadRemoteState({ fallbackToCache: false });
      if (!remote) {
        setText("settings-message", "Ainda nao ha dados salvos no Supabase para este workspace.");
        return;
      }
      state = sanitizeRemoteState(remote);
      saveLocalState(state);
      renderAll();
      setText("settings-message", `Dados do Supabase aplicados. Imoveis carregados: ${state.properties.length}.`);
    } catch (error) {
      setText("settings-message", `Nao foi possivel baixar do Supabase: ${error.message}`);
    }
    return;
  }
  if (!ensureSyncConfigured()) return;
  setText("settings-message", "Baixando dados da nuvem...");
  try {
    const response = await fetch(syncConfig.endpoint, { headers: getSyncHeaders() });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    state = sanitizeRemoteState(payload.state || payload);
    addAuditLog("cloud_download", "sync", "", null, { endpoint: syncConfig.endpoint }, false);
    saveState();
    renderAll();
    setText("settings-message", "Dados baixados e aplicados com sucesso.");
  } catch (error) {
    setText("settings-message", `Nao foi possivel baixar: ${error.message}`);
  }
}

async function uploadToCloud() {
  if (!requirePermission("admin:write", "Apenas administradores podem enviar dados para a nuvem.")) return;
  if (window.SupabaseSync) {
    setText("settings-message", "Enviando todos os dados deste navegador para o Supabase...");
    try {
      state = sanitizeRemoteState(state);
      addAuditLog("cloud_upload", "sync", "", null, { target: "Supabase", records: countBusinessRecords(state) }, false);
      saveLocalState(state);
      const result = window.SupabaseSync.saveRemoteStateNow
        ? await window.SupabaseSync.saveRemoteStateNow(state)
        : (window.SupabaseSync.saveRemoteState(state), null);
      const counts = result?.counts || {};
      setText(
        "settings-message",
        `Supabase atualizado com os dados deste navegador: ${counts.properties ?? state.properties.length} imoveis, ${counts.clients ?? state.clients.length} clientes, ${counts.contracts ?? state.contracts.length} contratos, ${counts.payments ?? state.payments.length} receitas e ${counts.expenses ?? state.expenses.length} despesas.`,
      );
    } catch (error) {
      setText("settings-message", `Nao foi possivel enviar ao Supabase: ${error.message}`);
    }
    return;
  }
  if (!ensureSyncConfigured()) return;
  setText("settings-message", "Enviando dados para a nuvem...");
  try {
    const response = await fetch(syncConfig.endpoint, {
      method: "PUT",
      headers: { ...getSyncHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify({ company: companyName, updatedAt: new Date().toISOString(), state }),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    addAuditLog("cloud_upload", "sync", "", null, { endpoint: syncConfig.endpoint }, false);
    setText("settings-message", "Dados enviados para a nuvem com sucesso.");
  } catch (error) {
    setText("settings-message", `Nao foi possivel enviar: ${error.message}`);
  }
}

function ensureSyncConfigured() {
  if (!syncConfig.endpoint) {
    setText("settings-message", "Informe e salve um endpoint HTTPS antes de sincronizar.");
    return false;
  }
  if (!syncConfig.endpoint.startsWith("https://")) {
    setText("settings-message", "Use um endpoint HTTPS para proteger os dados.");
    return false;
  }
  return true;
}

function getSyncHeaders() {
  return syncConfig.token ? { Authorization: `Bearer ${syncConfig.token}` } : {};
}

function sanitizeRemoteState(remoteState) {
  return {
    properties: Array.isArray(remoteState.properties) ? remoteState.properties : [],
    clients: Array.isArray(remoteState.clients) ? remoteState.clients : [],
    contracts: Array.isArray(remoteState.contracts) ? remoteState.contracts.map(normalizeContract) : [],
    expenses: Array.isArray(remoteState.expenses) ? remoteState.expenses.map(normalizeExpense) : [],
    payments: Array.isArray(remoteState.payments) ? remoteState.payments.map(normalizePayment) : [],
    auditLogs: Array.isArray(remoteState.auditLogs) ? remoteState.auditLogs : [],
  };
}

function updateSyncStatus() {
  const status = document.getElementById("sync-status");
  if (!status) return;
  if (window.SupabaseSync) {
    status.textContent = "Supabase conectado";
    return;
  }
  status.textContent = syncConfig.endpoint ? "Nuvem configurada" : "Offline local";
}


function getCurrentUser() {
  try {
    return JSON.parse(appSessionStorage.getItem(sessionUserKey));
  } catch {
    return null;
  }
}

function hasPermission(permission) {
  const user = getCurrentUser();
  const permissions = rolePermissions[user?.role || "consulta"] || rolePermissions.consulta;
  return permissions.includes("*") || permissions.includes(permission);
}

function requirePermission(permission, message) {
  if (hasPermission(permission)) return true;
  if (message) alert(message);
  return false;
}

function canAccessView(view) {
  if (view === "settings") return hasPermission("admin:write");
  return hasPermission("view");
}

function canWriteCollection(collection) {
  return hasPermission(collectionPermissions[collection] || "admin:write");
}

function canDeleteRecords() {
  return hasPermission("admin:write");
}

function isFinancialCollection(collection) {
  return ["contracts", "expenses", "payments"].includes(collection);
}

function applyPermissionUi() {
  const user = getCurrentUser();
  const badge = document.getElementById("current-user-badge");
  if (badge) badge.textContent = user ? `${user.username} - ${roleLabels[user.role] || user.role}` : "Sessao bloqueada";

  document.querySelectorAll("[data-view='settings']").forEach((item) => {
    item.hidden = !hasPermission("admin:write");
  });
  document.getElementById("clear-data")?.toggleAttribute("hidden", !hasPermission("admin:write"));

  setFormWriteState("property-form", canWriteCollection("properties"));
  setFormWriteState("client-form", canWriteCollection("clients"));
  setFormWriteState("contract-form", canWriteCollection("contracts"));
  setFormWriteState("expense-form", canWriteCollection("expenses"));
  setFormWriteState("payment-form", canWriteCollection("payments"));
}

function setFormWriteState(formId, enabled) {
  const form = document.getElementById(formId);
  if (!form) return;
  [...form.elements].forEach((element) => {
    if (element.type === "hidden") return;
    element.disabled = !enabled;
  });
}

function renderAll() {
  populateSelects();
  renderDashboard();
  renderProperties();
  renderClients();
  renderContracts();
  renderExpenses();
  renderPayments();
  renderFinancialErp();
  renderReports();
  renderAccessUsers();
  renderAuditLogs();
  applyPermissionUi();
  scheduleContractExpirationReminder();
}

function scheduleContractExpirationReminder() {
  if (document.body.classList.contains("locked")) return;
  if (appSessionStorage.getItem(reminderSessionKey) === "shown") return;
  const expiringContracts = getExpiringContracts(30);
  if (!expiringContracts.length) return;
  appSessionStorage.setItem(reminderSessionKey, "shown");
  setTimeout(() => showContractExpirationReminder(expiringContracts), 250);
}

function getExpiringContracts(daysAhead) {
  return state.contracts
    .map((contract) => ({
      contract,
      property: findProperty(contract.propertyId),
      client: findClient(contract.clientId),
      days: daysUntil(contract.endDate),
    }))
    .filter((item) => item.days >= 0 && item.days <= daysAhead)
    .sort((a, b) => a.days - b.days);
}

function showContractExpirationReminder(expiringContracts) {
  const visibleRows = expiringContracts.slice(0, 8).map((item) => {
    const property = item.property?.description || "Imovel nao localizado";
    const client = item.client?.name || "Cliente nao localizado";
    return `- ${property} | ${client} | vence em ${item.days} dia(s), em ${formatDate(item.contract.endDate)}`;
  });
  const extraCount = expiringContracts.length - visibleRows.length;
  const extraText = extraCount > 0 ? `\n\nE mais ${extraCount} contrato(s). Consulte o painel para ver todos.` : "";
  alert(`Lembrete: ${expiringContracts.length} contrato(s) vencem nos proximos 30 dias.\n\n${visibleRows.join("\n")}${extraText}`);
}

function populateSelects() {
  populateSelect(document.querySelector("#contract-form [name='propertyId']"), state.properties, "Selecione o imovel", "description");
  populateSelect(document.querySelector("#expense-form [name='propertyId']"), state.properties, "Selecione o imovel", "description");
  populateSelect(document.querySelector("#payment-form [name='propertyId']"), getPropertiesWithLinkedContracts(), "Selecione o imovel com contrato", "description");
  populateSelect(document.querySelector("#contract-form [name='clientId']"), state.clients, "Selecione o cliente", "name");
  populateSelect(document.getElementById("report-property"), state.properties, "Todos os imoveis", "description", true);
  populateSelect(document.getElementById("report-client"), state.clients, "Todos os clientes", "name", true);
  updatePaymentContractInfo();
}

function populateSelect(select, rows, placeholder, labelKey, includeAll = false) {
  const current = select.value;
  select.innerHTML = "";
  select.append(new Option(placeholder, includeAll ? "all" : ""));
  rows.forEach((row) => select.append(new Option(row[labelKey], row.id)));
  if ([...select.options].some((option) => option.value === current)) {
    select.value = current;
  }
}

function getPropertiesWithLinkedContracts() {
  const linkedPropertyIds = new Set(
    state.contracts
      .filter((contract) => getContractStatus(contract).key !== "expired")
      .map((contract) => contract.propertyId),
  );
  return state.properties.filter((property) => linkedPropertyIds.has(property.id));
}

function renderDashboard() {
  const activeContracts = state.contracts.filter((contract) => getContractStatus(contract).key !== "expired");
  const monthlyRevenue = activeContracts.reduce((sum, contract) => sum + contract.monthlyValue, 0);
  const expensesTotal = state.expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const receivedRevenue = state.payments.reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
  const netResult = receivedRevenue - expensesTotal;
  const occupiedProperties = new Set(activeContracts.map((contract) => contract.propertyId)).size;
  const occupancyRate = state.properties.length ? (occupiedProperties / state.properties.length) * 100 : 0;

  setText("metric-properties", state.properties.length);
  setText("metric-active-contracts", activeContracts.length);
  setText("metric-revenue", formatMoney(receivedRevenue || monthlyRevenue));
  setText("metric-expenses", formatMoney(expensesTotal));
  setText("metric-net", formatMoney(netResult));
  setText("metric-occupancy", `${formatNumber(occupancyRate)}%`);

  const upcoming = getExpiringContracts(90);

  setText("upcoming-count", `${upcoming.length} itens`);
  renderList(
    "upcoming-list",
    upcoming,
    (item) => `
      <strong>${escapeHtml(item.property?.description || "Imovel nao localizado")}</strong>
      <span>${escapeHtml(item.client?.name || "Cliente nao localizado")} - termina em ${item.days} dias</span>
      <span>Vigencia ate ${formatDate(item.contract.endDate)} | Reajuste: ${escapeHtml(item.contract.adjustmentFrequency)} por ${escapeHtml(item.contract.adjustmentMethod)}</span>
    `,
  );

  renderPropertyResult();
  renderDashboardCharts();
}

function renderPropertyResult() {
  updateFinancialPeriodCaption();
  const rows = state.properties.map(getPropertyFinancials);

  renderTable(
    "property-result-body",
    rows,
    (row) => `
      <td>
        <strong>${escapeHtml(row.property.description)}</strong>
        <span class="mini-line">${row.area ? `${formatArea(row.area)} m2` : "Area nao informada"}</span>
      </td>
      <td>${renderPeriodValues(row.revenue)}</td>
      <td>${renderPeriodValues(row.expenses)}</td>
      <td>${renderPeriodValues(row.net, true)}</td>
      <td>${renderPeriodValues(row.netPerSquareMeter, true)}</td>
    `,
  );
}

function getPropertyAccumulatedResult(propertyId) {
  const revenue = state.payments
    .filter((payment) => payment.propertyId === propertyId)
    .reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
  const expenses = state.expenses
    .filter((expense) => expense.propertyId === propertyId)
    .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  return revenue - expenses;
}

function getTotalAccumulatedResult() {
  return state.properties.reduce((sum, property) => sum + getPropertyAccumulatedResult(property.id), 0);
}

function calculatePropertyRoi(property, periodResult, periodMonths) {
  const investment = Number(property.investmentValue || 0);
  if (!investment) return { annual: 0, total: 0 };
  const accumulatedResult = getPropertyAccumulatedResult(property.id);
  return {
    annual: (periodResult / investment) * (12 / periodMonths) * 100,
    total: (accumulatedResult / investment) * 100,
  };
}

function renderDashboardCharts() {
  const financials = state.properties.map(getPropertyFinancials);
  const referenceDate = getFinancialReferenceDate();

  renderSimpleBarChart(
    "dashboard-revenue-chart",
    financials
      .map((row) => ({ label: row.property.description, value: row.revenue.current }))
      .filter((row) => row.value !== 0)
      .sort((a, b) => b.value - a.value),
    "revenue",
  );

  renderSimpleBarChart(
    "dashboard-net-chart",
    financials
      .map((row) => ({ label: row.property.description, value: row.net.accumulated }))
      .filter((row) => row.value !== 0)
      .sort((a, b) => b.value - a.value),
    "net",
  );

  const expenseGroups = state.expenses.reduce((groups, expense) => {
    const key = expense.expenseType || "Outros";
    groups[key] = (groups[key] || 0) + Number(expense.amount || 0);
    return groups;
  }, {});
  renderSimpleBarChart(
    "dashboard-expense-chart",
    Object.entries(expenseGroups)
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value),
    "expense",
  );

  renderDashboardMonthlyChart(referenceDate);
  renderDashboardContractChart();
}

function renderSimpleBarChart(id, rows, tone) {
  const target = document.getElementById(id);
  if (!target) return;
  if (!rows.length) {
    target.innerHTML = document.getElementById("empty-template").innerHTML;
    return;
  }

  const max = Math.max(...rows.map((row) => Math.abs(row.value)), 1);
  target.innerHTML = rows
    .map((row) => {
      const width = Math.max(3, Math.round((Math.abs(row.value) / max) * 100));
      const barClass = [
        "chart-bar",
        tone === "expense" ? "expense" : tone === "revenue" ? "revenue" : "",
        row.value < 0 ? "negative" : "",
      ]
        .filter(Boolean)
        .join(" ");
      return `
        <div class="chart-row">
          <div class="chart-label">
            <span>${escapeHtml(row.label)}</span>
            <strong>${formatMoney(row.value)}</strong>
          </div>
          <div class="chart-track">
            <div class="${barClass}" style="width: ${width}%"></div>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderDashboardMonthlyChart(referenceDate) {
  const target = document.getElementById("dashboard-monthly-chart");
  const caption = document.getElementById("dashboard-monthly-caption");
  if (!target) return;

  const year = referenceDate.getFullYear();
  if (caption) caption.textContent = `Receitas e despesas em ${year}`;

  const months = Array.from({ length: 12 }, (_, index) => {
    const start = new Date(year, index, 1);
    const end = new Date(year, index + 1, 0);
    const label = capitalize(new Intl.DateTimeFormat("pt-BR", { month: "short" }).format(start));
    const revenue = sumPaymentsInPeriod(state.payments, start, end);
    const expenses = sumExpensesInPeriod(state.expenses, start, end);
    return { label, revenue, expenses, net: revenue - expenses };
  }).filter((month) => month.revenue || month.expenses);

  if (!months.length) {
    target.innerHTML = document.getElementById("empty-template").innerHTML;
    return;
  }

  const max = Math.max(...months.flatMap((month) => [month.revenue, month.expenses]), 1);
  target.innerHTML = months
    .map((month) => `
      <div class="monthly-chart-row">
        <span class="monthly-label">${escapeHtml(month.label)}</span>
        <div class="monthly-bars">
          <div class="monthly-bar-wrap" title="Receita: ${formatMoney(month.revenue)}">
            <div class="chart-bar revenue" style="width: ${Math.max(3, Math.round((month.revenue / max) * 100))}%"></div>
          </div>
          <div class="monthly-bar-wrap" title="Despesas: ${formatMoney(month.expenses)}">
            <div class="chart-bar expense" style="width: ${Math.max(3, Math.round((month.expenses / max) * 100))}%"></div>
          </div>
        </div>
        <span class="monthly-net ${month.net < 0 ? "negative-text" : "positive-text"}">${formatMoney(month.net)}</span>
      </div>
    `)
    .join("");
}

function renderDashboardContractChart() {
  const target = document.getElementById("dashboard-contract-chart");
  const caption = document.getElementById("dashboard-contract-caption");
  if (!target) return;

  const groups = [
    { key: "active", label: "Ativos", tone: "active" },
    { key: "ending", label: "A vencer", tone: "ending" },
    { key: "expired", label: "Encerrados", tone: "expired" },
  ].map((group) => ({
    ...group,
    count: state.contracts.filter((contract) => getContractStatus(contract).key === group.key).length,
  }));

  const total = groups.reduce((sum, group) => sum + group.count, 0);
  if (caption) caption.textContent = `${total} contrato(s)`;

  if (!total) {
    target.innerHTML = document.getElementById("empty-template").innerHTML;
    return;
  }

  target.innerHTML = `
    <div class="contract-status-track">
      ${groups
        .filter((group) => group.count)
        .map((group) => {
          const width = Math.max(8, Math.round((group.count / total) * 100));
          return `<div class="contract-status-segment ${group.tone}" style="width: ${width}%" title="${group.label}: ${group.count}"></div>`;
        })
        .join("")}
    </div>
    <div class="contract-status-legend">
      ${groups
        .map(
          (group) => `
            <article class="contract-status-item">
              <span class="legend-dot ${group.tone}"></span>
              <div>
                <strong>${group.count}</strong>
                <span>${group.label}</span>
              </div>
            </article>
          `,
        )
        .join("")}
    </div>
  `;
}

function getPropertyFinancials(property) {
  const referenceDate = getFinancialReferenceDate();
  const currentMonthStart = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), 1);
  const currentMonthEnd = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + 1, 0);
  const yearStart = new Date(referenceDate.getFullYear(), 0, 1);
  const area = parseAreaValue(property.area);
  const propertyPayments = state.payments.filter((payment) => payment.propertyId === property.id);
  const revenue = getPaymentPeriodTotals(propertyPayments, currentMonthStart, currentMonthEnd, yearStart, referenceDate);

  const propertyExpenses = state.expenses.filter((expense) => expense.propertyId === property.id);
  const expenses = {
    current: sumExpensesInPeriod(propertyExpenses, currentMonthStart, currentMonthEnd),
    annual: sumExpensesInPeriod(propertyExpenses, yearStart, referenceDate),
    accumulated: propertyExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0),
  };
  const net = subtractPeriodTotals(revenue, expenses);
  const netPerSquareMeter = area ? dividePeriodTotals(net, area) : createPeriodTotals();

  return { property, area, revenue, expenses, net, netPerSquareMeter };
}

function getFinancialReferenceDate() {
  const dates = [
    ...state.expenses.map((expense) => parseDate(expense.expenseDate)),
    ...state.payments.map((payment) => parseDate(payment.paymentDate)),
    ...state.contracts.flatMap((contract) => [contract.updatedAt ? new Date(contract.updatedAt) : null, parseDate(contract.startDate)]),
  ].filter(Boolean);
  return dates.length ? new Date(Math.max(...dates.map((date) => date.getTime()))) : new Date();
}

function getPaymentPeriodTotals(payments, currentMonthStart, currentMonthEnd, yearStart, referenceDate) {
  return {
    current: sumPaymentsInPeriod(payments, currentMonthStart, currentMonthEnd),
    annual: sumPaymentsInPeriod(payments, yearStart, referenceDate),
    accumulated: payments.reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0),
  };
}

function getFinancialPeriodLabels() {
  const referenceDate = getFinancialReferenceDate();
  return {
    current: new Intl.DateTimeFormat("pt-BR", { month: "2-digit", year: "numeric" }).format(referenceDate),
    annual: String(referenceDate.getFullYear()),
    accumulated: "Acumulado",
  };
}

function updateFinancialPeriodCaption() {
  const caption = document.getElementById("financial-period-caption");
  if (!caption) return;
  const labels = getFinancialPeriodLabels();
  caption.textContent = `Competencia ${labels.current}, ano ${labels.annual} e acumulado`;
}

function createPeriodTotals() {
  return { current: 0, annual: 0, accumulated: 0 };
}

function subtractPeriodTotals(left, right) {
  return {
    current: left.current - right.current,
    annual: left.annual - right.annual,
    accumulated: left.accumulated - right.accumulated,
  };
}

function dividePeriodTotals(totals, divisor) {
  return {
    current: totals.current / divisor,
    annual: totals.annual / divisor,
    accumulated: totals.accumulated / divisor,
  };
}

function renderPeriodValues(totals, highlightBalance = false) {
  const labels = getFinancialPeriodLabels();
  return `
    <div class="period-values">
      ${renderPeriodValue(labels.current, totals.current, highlightBalance)}
      ${renderPeriodValue(labels.annual, totals.annual, highlightBalance)}
      ${renderPeriodValue(labels.accumulated, totals.accumulated, highlightBalance)}
    </div>
  `;
}

function renderPeriodValue(label, value, highlightBalance) {
  const tone = highlightBalance && value < 0 ? "negative" : highlightBalance && value > 0 ? "positive" : "";
  return `
    <span class="period-value ${tone}">
      <small>${label}</small>
      <strong>${formatMoney(value)}</strong>
    </span>
  `;
}

function sumExpensesInPeriod(expenses, startDate, endDate) {
  return expenses
    .filter((expense) => isDateInPeriod(parseDate(expense.expenseDate), startDate, endDate))
    .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
}

function sumPaymentsInPeriod(payments, startDate, endDate) {
  return payments
    .filter((payment) => isDateInPeriod(parseDate(payment.paymentDate), startDate, endDate))
    .reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
}

function countContractMonthsInPeriod(contract, periodStart, periodEnd) {
  const contractStart = parseDate(contract.startDate);
  const contractEnd = parseDate(contract.endDate);
  if (!contractStart || !contractEnd || !periodStart || !periodEnd) return 0;

  const start = maxDate(firstDayOfMonth(contractStart), firstDayOfMonth(periodStart));
  const end = minDate(firstDayOfMonth(contractEnd), firstDayOfMonth(periodEnd));
  if (start > end) return 0;
  return (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth() + 1;
}

function contractOverlapsPeriod(contract, periodStart, periodEnd) {
  const contractStart = parseDate(contract.startDate);
  const contractEnd = parseDate(contract.endDate);
  return Boolean(contractStart && contractEnd && contractStart <= periodEnd && contractEnd >= periodStart);
}

function isDateInPeriod(date, startDate, endDate) {
  return Boolean(date && startDate && endDate && date >= startDate && date <= endDate);
}

function parseDate(value) {
  if (!value) return null;
  const [year, month, day] = String(value).split("-").map(Number);
  if (!year || !month || !day) return null;
  return new Date(year, month - 1, day);
}

function firstDayOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function maxDate(left, right) {
  return left > right ? left : right;
}

function minDate(left, right) {
  return left < right ? left : right;
}

function parseAreaValue(area) {
  const match = String(area || "").match(/\d+(?:[.,]\d+)*/);
  if (!match) return 0;
  const value = match[0];
  const normalized = value.includes(",")
    ? value.replace(/\./g, "").replace(",", ".")
    : value.replace(/\.(?=\d{3}(?:\D|$))/g, "");
  return Number(normalized) || 0;
}

function formatArea(value) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(value);
}

function renderProperties() {
  renderTable(
    "properties-body",
    state.properties,
    (property) => `
      <td>${escapeHtml(property.description)}</td>
      <td>${escapeHtml(property.type)}</td>
      <td>${escapeHtml(property.area)}</td>
      <td>${escapeHtml(property.location)}</td>
      <td>${property.investmentValue ? formatMoney(property.investmentValue) : "-"}</td>
      <td>${renderDocumentLink(property.documentLink)}</td>
      <td>${actions("properties", property.id, "property-form")}</td>
    `,
  );
}

function renderDocumentLink(link) {
  if (!link) return "-";
  return `<a href="${escapeHtml(link)}" target="_blank" rel="noopener">Abrir documento</a>`;
}

function renderClients() {
  renderTable(
    "clients-body",
    state.clients,
    (client) => `
      <td>${escapeHtml(client.document)}</td>
      <td>${escapeHtml(client.name)}</td>
      <td>${escapeHtml(client.contact)}</td>
      <td>${escapeHtml(client.phone)}</td>
      <td>${escapeHtml(client.email || "-")}</td>
      <td>${actions("clients", client.id, "client-form")}</td>
    `,
  );
}

function renderContracts() {
  renderTable(
    "contracts-body",
    state.contracts,
    (contract) => {
      const property = findProperty(contract.propertyId);
      const client = findClient(contract.clientId);
      return `
        <td>${escapeHtml(property?.description || "-")}</td>
        <td>${escapeHtml(client?.name || "-")}</td>
        <td>${formatDate(contract.startDate)} a ${formatDate(contract.endDate)}</td>
        <td>${formatMoney(contract.monthlyValue)}</td>
        <td>${escapeHtml(contract.adjustmentFrequency)} - ${escapeHtml(contract.adjustmentMethod)}</td>
        <td>${renderChargeSummary(contract)}</td>
        <td>
          <div class="actions-cell">
            <button class="small-button" data-whatsapp="${contract.id}" type="button">WhatsApp</button>
            <button class="small-button" data-whatsapp-attachment="${contract.id}" type="button">WhatsApp + anexo</button>
            <button class="small-button" data-email="${contract.id}" type="button">E-mail</button>
          </div>
        </td>
        <td>${actions("contracts", contract.id, "contract-form")}</td>
      `;
    },
  );

  document.querySelectorAll("[data-whatsapp]").forEach((button) => {
    button.addEventListener("click", () => openWhatsApp(button.dataset.whatsapp));
  });
  document.querySelectorAll("[data-email]").forEach((button) => {
    button.addEventListener("click", () => openEmail(button.dataset.email));
  });
  document.querySelectorAll("[data-whatsapp-attachment]").forEach((button) => {
    button.addEventListener("click", () => shareChargesAttachment(button.dataset.whatsappAttachment));
  });
}

function renderExpenses() {
  renderTable(
    "expenses-body",
    state.expenses,
    (expense) => `
      <td>${escapeHtml(findProperty(expense.propertyId)?.description || "-")}</td>
      <td>${escapeHtml(expense.expenseType)}</td>
      <td>${formatDate(expense.expenseDate)}</td>
      <td>${formatMoney(expense.amount)}</td>
      <td>${escapeHtml(expense.note || "-")}</td>
      <td>${actions("expenses", expense.id, "expense-form")}</td>
    `,
  );
}

function renderPayments() {
  renderTable(
    "payments-body",
    state.payments,
    (payment) => {
      const contract = findPaymentContract(payment.propertyId, payment.paymentDate, payment.contractId);
      const client = findClient(contract?.clientId);
      return `
        <td>${escapeHtml(findProperty(payment.propertyId)?.description || "-")}</td>
        <td>${escapeHtml(payment.contractCode || (contract ? getContractCode(contract) : "-"))}</td>
        <td>${escapeHtml(payment.lessorName || client?.name || "-")}</td>
        <td>${formatDate(payment.paymentDate)}</td>
        <td>${formatMoney(payment.amount)}</td>
        <td>${formatMoney(payment.chargeAmount)}</td>
        <td>${formatMoney(payment.totalAmount)}</td>
        <td>${escapeHtml(payment.history || "-")}</td>
        <td>${actions("payments", payment.id, "payment-form")}</td>
      `;
    },
  );
}

function renderFinancialErp() {
  const period = getErpPeriod();
  const receivables = buildAutomaticReceivables(period);
  const payments = state.payments.filter((payment) => isDateInPeriod(parseDate(payment.paymentDate), period.startDate, period.endDate));
  const expenses = state.expenses.filter((expense) => isDateInPeriod(parseDate(expense.expenseDate), period.startDate, period.endDate));
  const receivedRevenue = payments.reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
  const expectedRevenue = receivables.reduce((sum, item) => sum + item.expected, 0);
  const expensesTotal = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const overdueTotal = receivables.filter((item) => item.statusKey === "overdue").reduce((sum, item) => sum + item.balance, 0);
  const operatingResult = receivedRevenue - expensesTotal;
  const operatingMargin = receivedRevenue ? (operatingResult / receivedRevenue) * 100 : 0;
  const totalInvestment = state.properties.reduce((sum, property) => sum + Number(property.investmentValue || 0), 0);
  const annualizedRoi = totalInvestment ? (operatingResult / totalInvestment) * (12 / period.months.length) * 100 : 0;
  const accumulatedResult = getTotalAccumulatedResult();
  const totalRoi = totalInvestment ? (accumulatedResult / totalInvestment) * 100 : 0;

  setText("erp-expected-revenue", formatMoney(expectedRevenue));
  setText("erp-received-revenue", formatMoney(receivedRevenue));
  setText("erp-overdue-total", formatMoney(overdueTotal));
  setText("erp-cash-balance", formatMoney(operatingResult));
  setText("erp-operating-margin", `${formatNumber(operatingMargin)}%`);
  setText("erp-roi", `${formatNumber(annualizedRoi)}%`);
  setText("erp-total-roi", `${formatNumber(totalRoi)}%`);
  setText("erp-expenses-total", formatMoney(expensesTotal));
  setText("erp-operating-result", formatMoney(operatingResult));
  setText("erp-dre-period", `${formatMonth(period.startDate)} a ${formatMonth(period.endDate)}`);

  renderDreList(receivedRevenue, expensesTotal, overdueTotal, expectedRevenue);
  renderErpReceivables(receivables);
  renderErpCashflow(period, payments, expenses);
  renderErpExpenseCategories(expenses);
  renderErpPropertyProfitability(period, payments, expenses);
}

function getErpPeriod() {
  const startInput = document.getElementById("erp-start");
  const endInput = document.getElementById("erp-end");
  const reference = getFinancialReferenceDate();
  const defaultStart = `${reference.getFullYear()}-01`;
  const defaultEnd = toMonthValue(reference);

  if (!startInput.value) startInput.value = defaultStart;
  if (!endInput.value) endInput.value = defaultEnd;
  if (startInput.value > endInput.value) endInput.value = startInput.value;

  const startDate = parseMonthValue(startInput.value);
  const endMonth = parseMonthValue(endInput.value);
  const endDate = new Date(endMonth.getFullYear(), endMonth.getMonth() + 1, 0);
  return { startDate, endDate, months: listMonths(startDate, endDate) };
}

function buildAutomaticReceivables(period) {
  const receivables = [];
  const activeContracts = state.contracts.filter((contract) => contractOverlapsPeriod(contract, period.startDate, period.endDate));

  activeContracts.forEach((contract) => {
    const contractStart = parseDate(contract.startDate);
    const contractEnd = parseDate(contract.endDate);
    const dueDay = contractStart?.getDate() || 10;
    period.months.forEach((monthDate) => {
      const monthStart = firstDayOfMonth(monthDate);
      const monthEnd = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
      if (!contractStart || !contractEnd || contractStart > monthEnd || contractEnd < monthStart) return;

      const dueDate = new Date(monthDate.getFullYear(), monthDate.getMonth(), Math.min(dueDay, monthEnd.getDate()));
      receivables.push({
        contract,
        property: findProperty(contract.propertyId),
        client: findClient(contract.clientId),
        dueDate,
        month: toMonthValue(monthDate),
        expected: Number(contract.monthlyValue || 0),
        received: 0,
      });
    });
  });

  const paymentsByPropertyMonth = state.payments.reduce((groups, payment) => {
    const paymentDate = parseDate(payment.paymentDate);
    if (!paymentDate || !isDateInPeriod(paymentDate, period.startDate, period.endDate)) return groups;
    const key = `${payment.propertyId}:${toMonthValue(paymentDate)}`;
    groups[key] = (groups[key] || 0) + Number(payment.totalAmount || 0);
    return groups;
  }, {});

  receivables
    .sort((a, b) => a.dueDate - b.dueDate)
    .forEach((item) => {
      const key = `${item.contract.propertyId}:${item.month}`;
      const available = paymentsByPropertyMonth[key] || 0;
      item.received = Math.min(item.expected, available);
      paymentsByPropertyMonth[key] = Math.max(available - item.received, 0);
      item.balance = Math.max(item.expected - item.received, 0);
      item.statusKey = getReceivableStatus(item);
      item.status = getReceivableStatusLabel(item.statusKey);
    });

  return receivables;
}

function getReceivableStatus(item) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (item.balance <= 0) return "paid";
  if (item.received > 0) return "partial";
  if (item.dueDate < today) return "overdue";
  return "open";
}

function getReceivableStatusLabel(status) {
  return {
    paid: "Recebido",
    partial: "Parcial",
    overdue: "Vencido",
    open: "Em aberto",
  }[status];
}

function renderDreList(revenue, expenses, overdue, expectedRevenue) {
  const rows = [
    ["Receita operacional recebida", revenue],
    ["(-) Despesas operacionais", -expenses],
    ["Resultado operacional", revenue - expenses],
    ["Contas a receber previstas", expectedRevenue],
    ["Inadimplencia vencida", -overdue],
  ];
  document.getElementById("erp-dre-list").innerHTML = rows
    .map(([label, value]) => `
      <div class="dre-row ${value < 0 ? "negative" : ""}">
        <span>${escapeHtml(label)}</span>
        <strong>${formatMoney(value)}</strong>
      </div>
    `)
    .join("");
}

function renderErpReceivables(receivables) {
  renderTable(
    "erp-receivables-body",
    receivables,
    (item) => `
      <td>${formatDate(toDateInputValue(item.dueDate))}</td>
      <td>${escapeHtml(item.property?.description || "-")}</td>
      <td>${escapeHtml(item.client?.name || "-")}</td>
      <td>${formatMoney(item.expected)}</td>
      <td>${formatMoney(item.received)}</td>
      <td>${formatMoney(item.balance)}</td>
      <td><span class="status ${item.statusKey}">${item.status}</span></td>
    `,
  );
}

function renderErpCashflow(period, payments, expenses) {
  const rows = period.months.map((monthDate) => {
    const month = toMonthValue(monthDate);
    const inflow = payments
      .filter((payment) => toMonthValue(parseDate(payment.paymentDate)) === month)
      .reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
    const outflow = expenses
      .filter((expense) => toMonthValue(parseDate(expense.expenseDate)) === month)
      .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
    return { monthDate, inflow, outflow, balance: inflow - outflow };
  });

  renderTable(
    "erp-cashflow-body",
    rows,
    (row) => `
      <td>${formatMonth(row.monthDate)}</td>
      <td>${formatMoney(row.inflow)}</td>
      <td>${formatMoney(row.outflow)}</td>
      <td><strong class="${row.balance < 0 ? "negative-text" : "positive-text"}">${formatMoney(row.balance)}</strong></td>
    `,
  );
}

function renderErpExpenseCategories(expenses) {
  const total = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const rows = Object.entries(
    expenses.reduce((groups, expense) => {
      const category = expense.expenseType || "Outros";
      groups[category] = (groups[category] || 0) + Number(expense.amount || 0);
      return groups;
    }, {}),
  )
    .map(([category, amount]) => ({ category, amount, share: total ? (amount / total) * 100 : 0 }))
    .sort((a, b) => b.amount - a.amount);

  renderTable(
    "erp-expense-category-body",
    rows,
    (row) => `
      <td>${escapeHtml(row.category)}</td>
      <td>${formatMoney(row.amount)}</td>
      <td>${formatNumber(row.share)}%</td>
    `,
  );
}

function renderErpPropertyProfitability(period, payments, expenses) {
  const rows = state.properties
    .map((property) => {
      const revenue = payments
        .filter((payment) => payment.propertyId === property.id)
        .reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
      const expenseTotal = expenses
        .filter((expense) => expense.propertyId === property.id)
        .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
      const result = revenue - expenseTotal;
      const margin = revenue ? (result / revenue) * 100 : 0;
      const roi = calculatePropertyRoi(property, result, period.months.length);
      return { property, revenue, expenses: expenseTotal, result, margin, roi };
    })
    .filter((row) => row.revenue || row.expenses || Number(row.property.investmentValue || 0))
    .sort((a, b) => b.result - a.result);

  renderTable(
    "erp-property-profitability-body",
    rows,
    (row) => `
      <td>${escapeHtml(row.property.description)}</td>
      <td>${formatMoney(row.revenue)}</td>
      <td>${formatMoney(row.expenses)}</td>
      <td><strong class="${row.result < 0 ? "negative-text" : "positive-text"}">${formatMoney(row.result)}</strong></td>
      <td>${formatNumber(row.margin)}%</td>
      <td>${Number(row.property.investmentValue || 0) ? `${formatNumber(row.roi.annual)}%` : "-"}</td>
      <td>${Number(row.property.investmentValue || 0) ? `${formatNumber(row.roi.total)}%` : "-"}</td>
    `,
  );
}

function renderAccessUsers() {
  const body = document.getElementById("access-users-body");
  if (!body) return;
  renderTable(
    "access-users-body",
    getStoredAccessUsers(),
    (user) => `
      <td>${escapeHtml(user.username)}</td>
      <td>${escapeHtml(roleLabels[user.role] || user.role)}</td>
      <td>${user.passwordHash ? "Hash SHA-256 + salt" : "Legado pendente"}</td>
      <td>${formatDateTime(user.updatedAt)}</td>
      <td>
        <div class="actions-cell">
          <button class="small-button" data-edit-user="${user.id}" type="button">Editar</button>
          <button class="small-button" data-delete-user="${user.id}" type="button">Excluir</button>
        </div>
      </td>
    `,
  );
}

function renderAuditLogs() {
  const body = document.getElementById("audit-log-body");
  if (!body) return;
  const rows = [...(state.auditLogs || [])].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 120);
  renderTable(
    "audit-log-body",
    rows,
    (log) => `
      <td>${formatDateTime(log.createdAt)}</td>
      <td>${escapeHtml(log.userName || "Sistema")}</td>
      <td>${escapeHtml(log.action)}</td>
      <td>${escapeHtml(log.collection)}</td>
      <td>${escapeHtml(getAuditType(log))}</td>
      <td>${escapeHtml(log.summary)}</td>
    `,
  );
}

function getAuditType(log) {
  if (log.collection === "auth" || log.collection === "users") return "Seguranca";
  if (log.financial) return "Financeiro";
  if (log.collection === "sync" || log.collection === "system") return "Sistema";
  return "Operacional";
}

function renderReports() {
  updateReportModeVisibility();
  const propertyId = document.getElementById("report-property").value;
  const clientId = document.getElementById("report-client").value;
  const status = document.getElementById("report-status").value;
  const filters = getReportFilters();
  const payments = getFilteredPayments(filters, propertyId, clientId, status);

  const rows = state.contracts
    .filter((contract) => propertyId === "all" || contract.propertyId === propertyId)
    .filter((contract) => clientId === "all" || contract.clientId === clientId)
    .filter((contract) => status === "all" || getContractStatus(contract).key === status)
    .filter((contract) => contractMatchesReportFilters(contract, filters))
    .map(toReportRow);

  renderReportMetrics(rows, payments);
  renderRevenueReport(payments);
  renderPropertyReports(rows, filters, payments);
  renderExpenseTypeReport(rows, filters);
  renderChargesReport(propertyId, clientId, status, filters);
  renderSummaryReport(rows, filters);

  renderTable(
    "reports-body",
    rows,
    (row) => `
      <td>${escapeHtml(row.property)}</td>
      <td>${escapeHtml(row.client)}</td>
      <td>${escapeHtml(row.contact)}</td>
      <td>${row.period}</td>
      <td>${formatMoney(row.monthlyValue)}</td>
      <td>${formatMoney(row.expenses)}</td>
      <td><span class="status ${row.statusKey}">${row.status}</span></td>
    `,
  );
}

function updateReportModeVisibility() {
  document.querySelectorAll(".analytic-report").forEach((item) => item.classList.toggle("hidden", reportMode !== "analytic"));
  const summary = document.getElementById("summary-report");
  if (summary) summary.classList.toggle("active", reportMode === "summary");
}

function getReportFilters() {
  return {
    expenseType: document.getElementById("report-expense-type").value,
    startDate: document.getElementById("report-start").value,
    endDate: document.getElementById("report-end").value,
    minValue: Number(document.getElementById("report-min-value").value || 0),
    maxValue: Number(document.getElementById("report-max-value").value || 0),
  };
}

function contractMatchesReportFilters(contract, filters) {
  const startsBeforeEnd = !filters.endDate || parseDate(contract.startDate) <= parseDate(filters.endDate);
  const endsAfterStart = !filters.startDate || parseDate(contract.endDate) >= parseDate(filters.startDate);
  const aboveMin = !filters.minValue || Number(contract.monthlyValue || 0) >= filters.minValue;
  const belowMax = !filters.maxValue || Number(contract.monthlyValue || 0) <= filters.maxValue;
  return startsBeforeEnd && endsAfterStart && aboveMin && belowMax;
}

function renderReportMetrics(rows, payments = getFilteredPayments()) {
  const revenue = payments.reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
  const chargesReceived = payments.reduce((sum, payment) => sum + Number(payment.chargeAmount || 0), 0);
  const ownerExpenses = rows.reduce((sum, row) => sum + row.ownerExpenses, 0);
  const averageTicket = payments.length ? revenue / payments.length : 0;
  const propertyTotals = payments.reduce((totals, payment) => {
    const property = findProperty(payment.propertyId)?.description || "-";
    totals[property] = (totals[property] || 0) + Number(payment.totalAmount || 0);
    return totals;
  }, {});
  const topProperty = Object.entries(propertyTotals).sort((a, b) => b[1] - a[1])[0]?.[0] || "-";
  const netMargin = revenue ? ((revenue - ownerExpenses) / revenue) * 100 : 0;

  setText("report-revenue", formatMoney(revenue));
  setText("report-owner-expenses", formatMoney(ownerExpenses));
  setText("report-net-revenue", formatMoney(revenue - ownerExpenses));
  setText("report-tenant-charges", formatMoney(chargesReceived));
  setText("report-contract-count", rows.length);
  setText("report-average-ticket", formatMoney(averageTicket));
  setText("report-top-property", topProperty);
  setText("report-net-margin", `${formatNumber(netMargin)}%`);
}

function renderSummaryReport(reportRows, filters = getReportFilters()) {
  const summary = getSummaryReportData(reportRows, filters);
  setText("summary-period", getSummaryPeriodLabel(filters));
  setText("summary-properties", summary.propertyCount);
  setText("summary-clients", summary.clientCount);
  setText("summary-active-contracts", summary.activeContracts);
  setText("summary-ending-contracts", summary.endingContracts);
  setText("summary-gross-revenue", formatMoney(summary.revenue));
  setText("summary-entered-expenses", formatMoney(summary.expenses));
  setText("summary-net-result", formatMoney(summary.netResult));
  setText("summary-net-margin", `${formatNumber(summary.netMargin)}%`);

  renderTable(
    "summary-report-body",
    [
      { indicator: "Carteira filtrada", result: `${summary.contractCount} contrato(s)`, note: `${summary.activeContracts} ativo(s), ${summary.endingContracts} a vencer e ${summary.expiredContracts} encerrado(s).` },
      { indicator: "Receita recebida", result: formatMoney(summary.revenue), note: `Ticket medio de ${formatMoney(summary.averageTicket)} por pagamento lancado.` },
      { indicator: "Encargos recebidos", result: formatMoney(summary.chargesReceived), note: `${summary.paymentCount} pagamento(s) lancado(s) no recorte atual.` },
      { indicator: "Despesas apropriadas", result: formatMoney(summary.expenses), note: `${summary.expenseCount} lancamento(s) de despesa no recorte atual.` },
      { indicator: "Resultado liquido", result: formatMoney(summary.netResult), note: `Margem gerencial de ${formatNumber(summary.netMargin)}% sobre a receita filtrada.` },
      { indicator: "Maior receita", result: summary.topProperty, note: summary.topProperty === "-" ? "Sem imovel com receita no filtro." : "Imovel com maior participacao na receita bruta." },
      { indicator: "Encargos do cliente", result: `${summary.tenantCharges} encargo(s)`, note: "Quantidade de impostos e taxas sob responsabilidade do cliente nos contratos filtrados." },
    ],
    (row) => `
      <td>${escapeHtml(row.indicator)}</td>
      <td>${escapeHtml(row.result)}</td>
      <td>${escapeHtml(row.note)}</td>
    `,
  );

  renderTable(
    "summary-property-body",
    summary.propertyRows,
    (row) => `
      <td>${escapeHtml(row.property)}</td>
      <td>${formatMoney(row.revenue)}</td>
      <td>${formatMoney(row.chargesReceived)}</td>
      <td>${formatMoney(row.expenses)}</td>
      <td>${formatMoney(row.netResult)}</td>
      <td>${formatNumber(row.participation)}%</td>
    `,
  );
}

function getSummaryReportData(reportRows, filters = getReportFilters()) {
  const propertyId = document.getElementById("report-property")?.value || "all";
  const clientId = document.getElementById("report-client")?.value || "all";
  const status = document.getElementById("report-status")?.value || "all";
  const payments = getFilteredPayments(filters, propertyId, clientId, status);
  const revenue = payments.reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
  const chargesReceived = payments.reduce((sum, payment) => sum + Number(payment.chargeAmount || 0), 0);
  const clientIds = new Set(reportRows.map((row) => row.clientId));
  const reportPropertyIds = new Set(reportRows.map((row) => row.propertyId));
  const paymentPropertyIds = new Set(payments.map((payment) => payment.propertyId));
  const expenses = getFilteredExpenses(filters).filter((expense) => reportPropertyIds.size || paymentPropertyIds.size ? reportPropertyIds.has(expense.propertyId) || paymentPropertyIds.has(expense.propertyId) : true);
  const propertyIds = new Set([...reportPropertyIds, ...paymentPropertyIds, ...expenses.map((expense) => expense.propertyId)]);
  const expensesTotal = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const activeContracts = reportRows.filter((row) => row.statusKey === "active").length;
  const endingContracts = reportRows.filter((row) => row.statusKey === "ending").length;
  const expiredContracts = reportRows.filter((row) => row.statusKey === "expired").length;
  const tenantCharges = getFilteredChargeRows().filter((row) => row.responsible === "cliente" && reportRows.some((reportRow) => reportRow.contractId === row.contractId)).length;
  const averageTicket = payments.length ? revenue / payments.length : 0;
  const netResult = revenue - expensesTotal;
  const netMargin = revenue ? (netResult / revenue) * 100 : 0;
  const propertyRows = [...propertyIds]
    .map((propertyId) => {
      const property = findProperty(propertyId);
      const propertyPayments = payments.filter((payment) => payment.propertyId === propertyId);
      const propertyRevenue = propertyPayments.reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
      const propertyCharges = propertyPayments.reduce((sum, payment) => sum + Number(payment.chargeAmount || 0), 0);
      const propertyExpenses = expenses.filter((expense) => expense.propertyId === propertyId).reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
      return {
        property: property?.description || "-",
        revenue: propertyRevenue,
        chargesReceived: propertyCharges,
        expenses: propertyExpenses,
        netResult: propertyRevenue - propertyExpenses,
        participation: revenue ? (propertyRevenue / revenue) * 100 : 0,
      };
    })
    .sort((a, b) => b.revenue - a.revenue);

  return {
    revenue,
    chargesReceived,
    paymentCount: payments.length,
    expenses: expensesTotal,
    expenseCount: expenses.length,
    netResult,
    netMargin,
    propertyCount: propertyIds.size,
    clientCount: clientIds.size,
    contractCount: reportRows.length,
    activeContracts,
    endingContracts,
    expiredContracts,
    tenantCharges,
    averageTicket,
    topProperty: propertyRows[0]?.property || "-",
    propertyRows,
  };
}

function getSummaryPeriodLabel(filters = getReportFilters()) {
  if (filters.startDate && filters.endDate) return `${formatDate(filters.startDate)} a ${formatDate(filters.endDate)}`;
  if (filters.startDate) return `A partir de ${formatDate(filters.startDate)}`;
  if (filters.endDate) return `Ate ${formatDate(filters.endDate)}`;
  return "Todos os periodos";
}

function renderRevenueReport(payments = getFilteredPayments()) {
  const rows = payments
    .map((payment) => ({
      ...payment,
      property: findProperty(payment.propertyId)?.description || "-",
    }))
    .sort((a, b) => String(b.paymentDate).localeCompare(String(a.paymentDate)));

  renderTable(
    "revenue-report-body",
    rows,
    (row) => `
      <td>${escapeHtml(row.property)}</td>
      <td>${formatDate(row.paymentDate)}</td>
      <td>${formatMoney(row.amount)}</td>
      <td>${formatMoney(row.chargeAmount)}</td>
      <td>${formatMoney(row.totalAmount)}</td>
      <td>${escapeHtml(row.history || "-")}</td>
    `,
  );
}

function renderPropertyReports(reportRows, filters = getReportFilters(), payments = getFilteredPayments(filters)) {
  const rows = state.properties
    .map((property) => {
      const propertyContracts = reportRows.filter((row) => row.propertyId === property.id);
      const revenue = payments.filter((payment) => payment.propertyId === property.id).reduce((sum, payment) => sum + Number(payment.totalAmount || 0), 0);
      const enteredExpenses = getEnteredExpenses(property.id, filters);
      const ownerCharges = propertyContracts.reduce((sum, row) => sum + row.ownerChargeCount, 0);
      const ownerExpenses = enteredExpenses;
      return {
        property: property.description,
        revenue,
        enteredExpenses,
        ownerCharges,
        netRevenue: revenue - ownerExpenses,
      };
    })
    .filter((row) => row.revenue > 0 || row.enteredExpenses > 0 || row.ownerCharges > 0);

  renderTable(
    "property-report-body",
    rows,
    (row) => `
      <td>${escapeHtml(row.property)}</td>
      <td>${formatMoney(row.revenue)}</td>
      <td>${formatMoney(row.enteredExpenses)}</td>
      <td>${row.ownerCharges} taxa(s)</td>
      <td>${formatMoney(row.netRevenue)}</td>
    `,
  );

  renderChart("expense-chart", rows, "enteredExpenses", "expense");
  renderChart("net-chart", rows, "netRevenue", "net");
}

function renderExpenseTypeReport(reportRows, filters = getReportFilters()) {
  const propertyIds = new Set(reportRows.map((row) => row.propertyId));
  const expenses = getFilteredExpenses(filters).filter((expense) => propertyIds.has(expense.propertyId));
  const total = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const grouped = expenses.reduce((rows, expense) => {
    const key = expense.expenseType || "Outros";
    rows[key] ||= { expenseType: key, count: 0, total: 0 };
    rows[key].count += 1;
    rows[key].total += Number(expense.amount || 0);
    return rows;
  }, {});

  renderTable(
    "expense-type-report-body",
    Object.values(grouped).sort((a, b) => b.total - a.total),
    (row) => `
      <td>${escapeHtml(row.expenseType)}</td>
      <td>${row.count}</td>
      <td>${formatMoney(row.total)}</td>
      <td>${total ? formatNumber((row.total / total) * 100) : "0"}%</td>
    `,
  );
}

function renderChargesReport(propertyId, clientId, status, filters = getReportFilters()) {
  const rows = getFilteredChargeRows(propertyId, clientId, status).filter((row) => contractMatchesReportFilters(row.contract, filters));

  renderTable(
    "charges-report-body",
    rows,
    (row) => `
      <td>${escapeHtml(row.property)}</td>
      <td>${escapeHtml(row.client)}</td>
      <td>${escapeHtml(row.charge)}</td>
      <td>${escapeHtml(capitalize(row.responsible))}</td>
      <td>${escapeHtml(row.baseDue)}</td>
      <td>${formatDate(row.adjustedDue)}</td>
    `,
  );
}

function renderChart(id, rows, valueKey, tone) {
  const target = document.getElementById(id);
  const visibleRows = rows.filter((row) => row[valueKey] !== 0);
  if (!visibleRows.length) {
    target.innerHTML = document.getElementById("empty-template").innerHTML;
    return;
  }

  const max = Math.max(...visibleRows.map((row) => Math.abs(row[valueKey])));
  target.innerHTML = visibleRows
    .map((row) => {
      const width = Math.max(3, Math.round((Math.abs(row[valueKey]) / max) * 100));
      const barClass = [
        "chart-bar",
        tone === "expense" ? "expense" : "",
        row[valueKey] < 0 ? "negative" : "",
      ].join(" ");
      return `
        <div class="chart-row">
          <div class="chart-label">
            <span>${escapeHtml(row.property)}</span>
            <strong>${formatMoney(row[valueKey])}</strong>
          </div>
          <div class="chart-track">
            <div class="${barClass}" style="width: ${width}%"></div>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderChargeSummary(contract) {
  return chargeRules
    .map((rule) => {
      const responsible = contract[rule.key] || "cliente";
      return `<span class="mini-line">${escapeHtml(rule.label)}: ${escapeHtml(capitalize(responsible))}</span>`;
    })
    .join("");
}

function addAuditLog(action, collection, recordId, before, after, financial = false) {
  const user = getCurrentUser();
  const beforeSummary = summarizeRecord(before);
  const afterSummary = summarizeRecord(after);
  const summary = beforeSummary && afterSummary
    ? `${beforeSummary} -> ${afterSummary}`
    : afterSummary || beforeSummary || "-";
  state.auditLogs = [
    ...(state.auditLogs || []),
    {
      id: uid("audit"),
      createdAt: new Date().toISOString(),
      userId: user?.id || "system",
      userName: user?.username || "Sistema",
      userRole: user?.role || "system",
      action,
      collection,
      recordId,
      financial,
      summary,
    },
  ].slice(-500);
  saveState();
}

function summarizeRecord(record) {
  if (!record) return "";
  if (record.username) return `${record.username} (${roleLabels[record.role] || record.role || "sem perfil"})`;
  if (record.description) return record.description;
  if (record.name) return record.name;
  if (record.paymentDate) return `${formatDate(record.paymentDate)} ${formatMoney(record.totalAmount || record.amount)}`;
  if (record.expenseDate) return `${formatDate(record.expenseDate)} ${formatMoney(record.amount)} ${record.expenseType || ""}`.trim();
  if (record.monthlyValue) return `${formatMoney(record.monthlyValue)} ${record.startDate || ""}`.trim();
  if (record.message) return record.message;
  if (record.endpoint) return record.endpoint;
  return record.id || JSON.stringify(record).slice(0, 80);
}

function summarizeUser(user) {
  if (!user) return null;
  return { id: user.id, username: user.username, role: user.role };
}

function renderTable(bodyId, rows, rowTemplate) {
  const body = document.getElementById(bodyId);
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="8">${document.getElementById("empty-template").innerHTML}</td></tr>`;
    return;
  }
  body.innerHTML = rows.map((row) => `<tr>${rowTemplate(row)}</tr>`).join("");
}

function renderList(id, rows, template) {
  const target = document.getElementById(id);
  if (!rows.length) {
    target.innerHTML = document.getElementById("empty-template").innerHTML;
    return;
  }
  target.innerHTML = rows.map((row) => `<article class="list-item">${template(row)}</article>`).join("");
}

function actions(collection, id, formId) {
  const editButton = canWriteCollection(collection) ? `<button class="small-button" data-edit="${collection}:${id}:${formId}" type="button">Editar</button>` : "";
  const deleteButton = canDeleteRecords() ? `<button class="small-button" data-delete="${collection}:${id}" type="button">Excluir</button>` : "";
  if (!editButton && !deleteButton) return "-";
  return `
    <div class="actions-cell">
      ${editButton}
      ${deleteButton}
    </div>
  `;
}

function editRecord(collection, id, formId) {
  if (!canWriteCollection(collection)) {
    alert("Seu perfil nao permite editar este registro.");
    return;
  }
  const record = state[collection].find((item) => item.id === id);
  const form = document.getElementById(formId);
  if (!record) return;

  Object.entries(record).forEach(([key, value]) => {
    if (form.elements[key]) form.elements[key].value = value;
  });
  if (formId === "payment-form") {
    updatePaymentTotal(form);
    updatePaymentContractInfo(form);
  }
  form.scrollIntoView({ behavior: "smooth", block: "start" });
}

function bindTableActions() {
  document.querySelector(".content").addEventListener("click", (event) => {
    const editUserButton = event.target.closest("[data-edit-user]");
    if (editUserButton) {
      editAccessUser(editUserButton.dataset.editUser);
      return;
    }

    const deleteUserButton = event.target.closest("[data-delete-user]");
    if (deleteUserButton) {
      deleteAccessUser(deleteUserButton.dataset.deleteUser);
      return;
    }

    const editButton = event.target.closest("[data-edit]");
    if (editButton) {
      const [collection, id, formId] = editButton.dataset.edit.split(":");
      editRecord(collection, id, formId);
      return;
    }

    const deleteButton = event.target.closest("[data-delete]");
    if (deleteButton) {
      const [collection, id] = deleteButton.dataset.delete.split(":");
      deleteRecord(collection, id);
    }
  });
}

function deleteRecord(collection, id) {
  if (!requirePermission("admin:write", "Apenas administradores podem excluir registros.")) return;
  if (!confirm("Deseja excluir este registro?")) return;
  const before = state[collection].find((item) => item.id === id);
  state[collection] = state[collection].filter((item) => item.id !== id);
  addAuditLog("record_deleted", collection, id, before, null, isFinancialCollection(collection));
  saveState();
  renderAll();
}

function editAccessUser(id) {
  if (!requirePermission("admin:write", "Apenas administradores podem editar usuarios.")) return;
  const user = getStoredAccessUsers().find((item) => item.id === id);
  const form = document.getElementById("access-form");
  if (!user || !form) return;
  form.elements.id.value = user.id;
  form.elements.username.value = user.username;
  form.elements.password.value = "";
  form.elements.role.value = user.role || "consulta";
  form.scrollIntoView({ behavior: "smooth", block: "start" });
  setText("settings-message", "Informe uma nova senha para alterar ou salve sem senha para manter a atual.");
}

function deleteAccessUser(id) {
  if (!requirePermission("admin:write", "Apenas administradores podem excluir usuarios.")) return;
  const users = getStoredAccessUsers();
  const user = users.find((item) => item.id === id);
  if (!user) return;
  if (users.length === 1) {
    setText("settings-message", "Mantenha pelo menos um usuario de acesso.");
    return;
  }
  if (!confirm(`Deseja excluir o usuario ${user.username}?`)) return;
  saveAuthUsers(users.filter((item) => item.id !== id));
  addAuditLog("user_deleted", "users", user.id, summarizeUser(user), null, false);
  renderAccessUsers();
  setText("settings-message", "Usuario excluido.");
}

function toReportRow(contract) {
  const property = findProperty(contract.propertyId);
  const client = findClient(contract.clientId);
  const expenses = state.expenses
    .filter((expense) => expense.propertyId === contract.propertyId)
    .reduce((sum, expense) => sum + expense.amount, 0);
  const ownerChargeCount = chargeRules.filter((rule) => (contract[rule.key] || "cliente") === "locador").length;
  const status = getContractStatus(contract);

  return {
    contractId: contract.id,
    propertyId: contract.propertyId,
    clientId: contract.clientId,
    property: property?.description || "-",
    client: client?.name || "-",
    contact: client ? `${client.contact} | ${client.phone}` : "-",
    period: `${formatDate(contract.startDate)} a ${formatDate(contract.endDate)}`,
    monthlyValue: contract.monthlyValue,
    expenses,
    ownerExpenses: expenses,
    ownerChargeCount,
    status: status.label,
    statusKey: status.key,
  };
}

function getContractStatus(contract) {
  const days = daysUntil(contract.endDate);
  if (days < 0) return { key: "expired", label: "Encerrado" };
  if (days <= 90) return { key: "ending", label: "A vencer" };
  return { key: "active", label: "Ativo" };
}

function openWhatsApp(contractId) {
  const message = buildContractMessage(contractId);
  if (!message.client?.phone) {
    alert("Cliente sem telefone cadastrado.");
    return;
  }
  const phone = message.client.phone.replace(/\D/g, "");
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message.text)}`, "_blank");
}

function openEmail(contractId) {
  const message = buildContractMessage(contractId);
  if (!message.client?.email) {
    alert("Cliente sem e-mail cadastrado.");
    return;
  }
  const subject = encodeURIComponent("Aviso sobre contrato de locacao");
  const body = encodeURIComponent(message.text);
  window.location.href = `mailto:${message.client.email}?subject=${subject}&body=${body}`;
}

async function shareChargesAttachment(contractId) {
  const message = buildContractMessage(contractId);
  const attachment = buildChargesAttachment(contractId);
  if (!attachment || !message.client?.phone) {
    alert("Contrato sem cliente, telefone ou taxas para gerar anexo.");
    return;
  }

  const file = new File([attachment.csv], attachment.fileName, { type: "text/csv" });
  const sharePayload = {
    title: "Impostos e taxas do contrato",
    text: message.text,
    files: [file],
  };

  if (navigator.canShare && navigator.canShare(sharePayload) && navigator.share) {
    await navigator.share(sharePayload);
    return;
  }

  downloadTextFile(attachment.csv, attachment.fileName, "text/csv;charset=utf-8");
  openWhatsApp(contractId);
  alert("O anexo foi baixado. No WhatsApp, clique no icone de anexar e selecione o arquivo gerado.");
}

function buildChargesAttachment(contractId) {
  const contract = state.contracts.find((item) => item.id === contractId);
  if (!contract) return null;

  const property = findProperty(contract.propertyId);
  const client = findClient(contract.clientId);
  const rows = chargeRules.map((rule) => {
    const dueDate = getChargeDueDate(rule);
    return [
      property?.description || "-",
      client?.name || "-",
      rule.label,
      capitalize(contract[rule.key] || "cliente"),
      rule.baseLabel,
      formatDate(toIsoDate(adjustToPreviousBusinessDay(dueDate))),
    ];
  });

  const csvRows = [
    ["Imovel", "Cliente", "Imposto ou taxa", "Responsavel", "Vencimento base", "Vencimento ajustado"],
    ...rows,
  ];
  const csv = csvRows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(";")).join("\n");
  const safeName = `${property?.description || "imovel"}-${client?.name || "cliente"}`
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/gi, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();

  return {
    csv,
    fileName: `impostos-taxas-${safeName || "contrato"}.csv`,
  };
}

function downloadTextFile(content, fileName, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
}

function buildContractMessage(contractId) {
  const contract = state.contracts.find((item) => item.id === contractId);
  const client = findClient(contract?.clientId);
  const property = findProperty(contract?.propertyId);
  const dueDate = nextDueDate(contract?.dueDay);
  const text = `Ola, ${client?.contact || client?.name || ""}. Lembramos que o contrato do imovel ${property?.description || ""} possui aluguel mensal de ${formatMoney(contract?.monthlyValue || 0)} com vencimento em ${formatDate(dueDate)}. Vigencia atual: ${formatDate(contract?.startDate)} a ${formatDate(contract?.endDate)}.`;
  return { client, text };
}

function nextDueDate(day) {
  const today = new Date();
  const due = new Date(today.getFullYear(), today.getMonth(), Math.min(Number(day || 1), 28));
  if (due < today) due.setMonth(due.getMonth() + 1);
  return due.toISOString().slice(0, 10);
}

function exportReportsCsv() {
  const rows = reportMode === "summary"
    ? [["Indicador", "Resultado", "Leitura gerencial"]]
    : [["Imovel", "Data", "Pagamento", "Encargo", "Total recebido", "Historico"]];
  const selector = reportMode === "summary" ? "#summary-report-body tr" : "#revenue-report-body tr";
  document.querySelectorAll(selector).forEach((tr) => {
    const cells = [...tr.querySelectorAll("td")].map((td) => td.innerText.replace(/\s+/g, " ").trim());
    if (cells.length) rows.push(cells);
  });

  const csv = rows.map((row) => row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(";")).join("\n");
  downloadTextFile(csv, reportMode === "summary" ? "relatorio-gerencial-locacoes.csv" : "relatorio-locacoes.csv", "text/csv;charset=utf-8");
}

function exportReportsExcel() {
  renderReports();
  const analyticTables = [
    { title: "Receitas lancadas", selector: "#revenue-report-body", headers: ["Imovel", "Data", "Pagamento", "Encargo", "Total recebido", "Historico"] },
    { title: "Resultado por imovel", selector: "#property-report-body", headers: ["Imovel", "Receita recebida", "Despesas apropriadas", "Taxas do locador", "Receita liquida"] },
    { title: "Despesas por tipo", selector: "#expense-type-report-body", headers: ["Despesa", "Quantidade", "Total", "Participacao"] },
    { title: "Encargos e vencimentos", selector: "#charges-report-body", headers: ["Imovel", "Cliente", "Encargo", "Responsavel", "Vencimento base", "Vencimento ajustado"] },
    { title: "Contratos filtrados", selector: "#reports-body", headers: ["Imovel", "Cliente", "Contato", "Vigencia", "Valor mensal", "Despesa vinculada", "Status"] },
  ];
  const summaryTables = [
    { title: "Resumo executivo", selector: "#summary-report-body", headers: ["Indicador", "Resultado", "Leitura gerencial"] },
    { title: "Resultado gerencial por imovel", selector: "#summary-property-body", headers: ["Imovel", "Receita", "Encargos", "Despesas", "Resultado", "Participacao na receita"] },
  ];
  const tables = reportMode === "summary" ? summaryTables : analyticTables;
  const sections = tables.map((table) => `
    <h2>${escapeHtml(table.title)}</h2>
    <table>
      <thead><tr>${table.headers.map((header) => `<th>${escapeHtml(header)}</th>`).join("")}</tr></thead>
      <tbody>${document.querySelector(table.selector).innerHTML}</tbody>
    </table>
  `);
  const workbook = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head><meta charset="UTF-8" /></head>
      <body>${sections.join("<br />")}</body>
    </html>
  `;
  downloadTextFile(workbook, reportMode === "summary" ? "relatorio-gerencial-locacoes.xls" : "relatorio-locacoes.xls", "application/vnd.ms-excel;charset=utf-8");
}

function exportReportsPdf() {
  renderReports();
  const report = document.getElementById("reports").cloneNode(true);
  report.querySelectorAll("button").forEach((button) => button.remove());
  const styles = document.querySelector("link[rel='stylesheet']").href;
  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    alert("Permita pop-ups para gerar o PDF.");
    return;
  }

  printWindow.document.write(`
    <!doctype html>
    <html lang="pt-BR">
      <head>
        <meta charset="UTF-8" />
        <title>Relatorio - ${companyName}</title>
        <link rel="stylesheet" href="${styles}" />
        <style>
          body { background: #fff; padding: 24px; }
          .view { display: grid; gap: 18px; }
          .print-header { display: flex; align-items: center; gap: 18px; margin-bottom: 18px; }
          .print-header img { width: 220px; }
          .report-actions, .filters { display: none; }
          .panel, .metric { box-shadow: none; } .metrics-grid, .summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .metric, .summary-item { min-width: 0; overflow: hidden; } .metric strong, .summary-item strong { display: block; font-size: 16px; line-height: 1.15; overflow-wrap: anywhere; word-break: break-word; } #report-top-property { font-size: 13px; } table { table-layout: fixed; width: 100%; } th, td { overflow-wrap: anywhere; word-break: break-word; font-size: 11px; }
        </style>
      </head>
      <body>
        <header class="print-header">
          <img src="logo-imobiliaria-rio.svg" alt="${companyName}" />
          <div>
            <h1>Relatorio ${reportMode === "summary" ? "sintetico gerencial" : "analitico"}</h1>
            <p>Gerado em ${formatDate(toIsoDate(new Date()))}</p>
          </div>
        </header>
        ${report.outerHTML}
      </body>
    </html>
  `);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => printWindow.print(), 400);
}

function createSampleData() {
  const propertyA = { id: uid("property"), description: "Sala comercial 204", type: "Sala comercial", area: "45 m2", location: "Aldeota, Fortaleza" };
  const propertyB = { id: uid("property"), description: "Terreno BR-116", type: "Terreno", area: "1.800 m2", location: "Eusebio, CE" };
  const clientA = { id: uid("client"), document: "12.345.678/0001-90", name: "Comercial Lima Ltda", contact: "Mariana Lima", phone: "5585999999999", email: "cliente@example.com" };
  const clientB = { id: uid("client"), document: "123.456.789-00", name: "Joao Pereira", contact: "Joao Pereira", phone: "5585888888888", email: "joao@example.com" };

  return {
    properties: [propertyA, propertyB],
    clients: [clientA, clientB],
    contracts: [
      { id: uid("contract"), propertyId: propertyA.id, clientId: clientA.id, startDate: "2026-01-01", endDate: "2027-01-01", monthlyValue: 2800, adjustmentFrequency: "Anual", adjustmentMethod: "IPCA", dueDay: 10, condoFeeResponsible: "cliente", iptuResponsible: "locador", spuResponsible: "locador", fireFeeResponsible: "cliente" },
      { id: uid("contract"), propertyId: propertyB.id, clientId: clientB.id, startDate: "2025-08-01", endDate: "2026-07-31", monthlyValue: 5200, adjustmentFrequency: "Anual", adjustmentMethod: "IGP-M", dueDay: 5, condoFeeResponsible: "locador", iptuResponsible: "cliente", spuResponsible: "cliente", fireFeeResponsible: "cliente" },
    ],
    expenses: [
      { id: uid("expense"), propertyId: propertyA.id, expenseType: "Manutencao", expenseDate: "2026-05-10", amount: 450, note: "Reparo eletrico" },
      { id: uid("expense"), propertyId: propertyB.id, expenseType: "Impostos e taxas", expenseDate: "2026-04-20", amount: 1300, note: "Taxa municipal" },
    ],
    payments: [
      { id: uid("payment"), propertyId: propertyA.id, paymentDate: "2026-05-10", amount: 2800, chargeAmount: 0, totalAmount: 2800, history: "Pagamento no vencimento" },
      { id: uid("payment"), propertyId: propertyB.id, paymentDate: "2026-05-12", amount: 5200, chargeAmount: 180, totalAmount: 5380, history: "Pagamento com encargo por atraso" },
    ],
  };
}

function getFilteredChargeRows(propertyId = document.getElementById("report-property")?.value || "all", clientId = document.getElementById("report-client")?.value || "all", status = document.getElementById("report-status")?.value || "all") {
  return state.contracts
    .filter((contract) => propertyId === "all" || contract.propertyId === propertyId)
    .filter((contract) => clientId === "all" || contract.clientId === clientId)
    .filter((contract) => status === "all" || getContractStatus(contract).key === status)
    .flatMap((contract) => {
      const property = findProperty(contract.propertyId);
      const client = findClient(contract.clientId);
      return chargeRules.map((rule) => {
        const dueDate = getChargeDueDate(rule);
        return {
          property: property?.description || "-",
          client: client?.name || "-",
          charge: rule.label,
          contract,
          contractId: contract.id,
          responsible: contract[rule.key] || "cliente",
          baseDue: rule.baseLabel,
          adjustedDue: toIsoDate(adjustToPreviousBusinessDay(dueDate)),
        };
      });
    });
}

function getChargeDueDate(rule) {
  const today = new Date();
  if (rule.kind === "monthly") {
    const dueDate = new Date(today.getFullYear(), today.getMonth(), rule.day);
    if (dueDate < today) dueDate.setMonth(dueDate.getMonth() + 1);
    return dueDate;
  }

  const dueDate = new Date(today.getFullYear(), rule.month, rule.day);
  if (dueDate < today) dueDate.setFullYear(dueDate.getFullYear() + 1);
  return dueDate;
}

function adjustToPreviousBusinessDay(date) {
  const adjusted = new Date(date);
  while (adjusted.getDay() === 0 || adjusted.getDay() === 6) {
    adjusted.setDate(adjusted.getDate() - 1);
  }
  return adjusted;
}

function toIsoDate(date) {
  return date.toISOString().slice(0, 10);
}

function getFilteredExpenses(filters = getReportFilters()) {
  return state.expenses
    .filter((expense) => filters.expenseType === "all" || expense.expenseType === filters.expenseType)
    .filter((expense) => !filters.startDate || parseDate(expense.expenseDate) >= parseDate(filters.startDate))
    .filter((expense) => !filters.endDate || parseDate(expense.expenseDate) <= parseDate(filters.endDate));
}

function getFilteredPayments(filters = getReportFilters(), propertyId = document.getElementById("report-property")?.value || "all", clientId = document.getElementById("report-client")?.value || "all", status = document.getElementById("report-status")?.value || "all") {
  const allowedProperties = getAllowedPaymentPropertyIds(clientId, status);
  return state.payments
    .filter((payment) => propertyId === "all" || payment.propertyId === propertyId)
    .filter((payment) => !allowedProperties || allowedProperties.has(payment.propertyId))
    .filter((payment) => !filters.startDate || parseDate(payment.paymentDate) >= parseDate(filters.startDate))
    .filter((payment) => !filters.endDate || parseDate(payment.paymentDate) <= parseDate(filters.endDate))
    .filter((payment) => !filters.minValue || Number(payment.totalAmount || 0) >= filters.minValue)
    .filter((payment) => !filters.maxValue || Number(payment.totalAmount || 0) <= filters.maxValue);
}

function getAllowedPaymentPropertyIds(clientId, status) {
  if (clientId === "all" && status === "all") return null;
  return new Set(
    state.contracts
      .filter((contract) => clientId === "all" || contract.clientId === clientId)
      .filter((contract) => status === "all" || getContractStatus(contract).key === status)
      .map((contract) => contract.propertyId),
  );
}

function getEnteredExpenses(propertyId, filters = getReportFilters()) {
  return getFilteredExpenses(filters)
    .filter((expense) => expense.propertyId === propertyId)
    .reduce((sum, expense) => sum + expense.amount, 0);
}

function capitalize(value) {
  return String(value || "").charAt(0).toUpperCase() + String(value || "").slice(1);
}

function findProperty(id) {
  return state.properties.find((property) => property.id === id);
}

function findClient(id) {
  return state.clients.find((client) => client.id === id);
}

function findPaymentContract(propertyId, paymentDate, preferredContractId = "") {
  if (!propertyId) return null;
  const matchingContracts = state.contracts.filter((contract) => contract.propertyId === propertyId);
  if (!matchingContracts.length) return null;

  if (preferredContractId) {
    const preferred = matchingContracts.find((contract) => contract.id === preferredContractId);
    if (preferred) return preferred;
  }

  const date = parseDate(paymentDate);
  if (date) {
    const covering = matchingContracts.find((contract) => {
      const start = parseDate(contract.startDate);
      const end = parseDate(contract.endDate);
      return start && end && date >= start && date <= end;
    });
    if (covering) return covering;
  }

  return matchingContracts.find((contract) => getContractStatus(contract).key !== "expired") || null;
}

function getContractCode(contract) {
  if (!contract?.id) return "";
  return String(contract.id).replace(/^contract-?/, "CTR-").slice(0, 12).toUpperCase();
}

function daysUntil(dateString) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(`${dateString}T00:00:00`);
  return Math.ceil((target - today) / 86400000);
}

function toMonthValue(date) {
  if (!date) return "";
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function parseMonthValue(value) {
  const [year, month] = String(value || "").split("-").map(Number);
  return new Date(year || new Date().getFullYear(), (month || 1) - 1, 1);
}

function listMonths(startDate, endDate) {
  const months = [];
  const cursor = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
  const end = new Date(endDate.getFullYear(), endDate.getMonth(), 1);
  while (cursor <= end) {
    months.push(new Date(cursor));
    cursor.setMonth(cursor.getMonth() + 1);
  }
  return months.length ? months : [new Date(startDate.getFullYear(), startDate.getMonth(), 1)];
}

function toDateInputValue(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function formatMonth(date) {
  return new Intl.DateTimeFormat("pt-BR", { month: "2-digit", year: "numeric" }).format(date);
}

function formatMoney(value) {
  return moneyFormatter.format(Number(value || 0));
}

function formatNumber(value) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(Number(value || 0));
}

function formatDate(dateString) {
  if (!dateString) return "-";
  return dateFormatter.format(new Date(`${dateString}T00:00:00Z`));
}

function formatDateTime(dateString) {
  if (!dateString) return "-";
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(new Date(dateString));
}

function setText(id, value) {
  document.getElementById(id).textContent = value;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}


/* =========================================================================
 * Exportacoes do ERP financeiro - PDF, Excel (xlsx) e CSV
 * Usa SheetJS (XLSX global) e jsPDF + autoTable carregados via CDN no HTML.
 * Em caso de bloqueio da CDN, fallback para .xls (HTML) e janela de impressao.
 * ========================================================================= */

function getErpExportData() {
  renderFinancialErp();
  const period = getErpPeriod();
  const receivables = buildAutomaticReceivables(period);
  const payments = state.payments.filter((p) =>
    isDateInPeriod(parseDate(p.paymentDate), period.startDate, period.endDate),
  );
  const expenses = state.expenses.filter((e) =>
    isDateInPeriod(parseDate(e.expenseDate), period.startDate, period.endDate),
  );
  const receivedRevenue = payments.reduce((s, p) => s + Number(p.totalAmount || 0), 0);
  const expectedRevenue = receivables.reduce((s, i) => s + i.expected, 0);
  const expensesTotal = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);
  const overdueTotal = receivables
    .filter((i) => i.statusKey === "overdue")
    .reduce((s, i) => s + i.balance, 0);
  const operatingResult = receivedRevenue - expensesTotal;
  const operatingMargin = receivedRevenue ? (operatingResult / receivedRevenue) * 100 : 0;
  const totalInvestment = state.properties.reduce(
    (s, p) => s + Number(p.investmentValue || 0),
    0,
  );
  const annualizedRoi = totalInvestment
    ? (operatingResult / totalInvestment) * (12 / period.months.length) * 100
    : 0;
  const accumulatedResult = getTotalAccumulatedResult();
  const totalRoi = totalInvestment ? (accumulatedResult / totalInvestment) * 100 : 0;

  const summary = [
    ["Periodo", `${formatMonth(period.startDate)} a ${formatMonth(period.endDate)}`],
    ["Recebiveis previstos", formatMoney(expectedRevenue)],
    ["Recebido no periodo", formatMoney(receivedRevenue)],
    ["Inadimplencia vencida", formatMoney(overdueTotal)],
    ["Despesas operacionais", formatMoney(expensesTotal)],
    ["Resultado operacional", formatMoney(operatingResult)],
    ["Margem operacional", `${formatNumber(operatingMargin)}%`],
    ["ROI anualizado", `${formatNumber(annualizedRoi)}%`],
    ["ROI total acumulado", `${formatNumber(totalRoi)}%`],
  ];

  const receivablesRows = receivables.map((i) => [
    formatDate(toDateInputValue(i.dueDate)),
    i.property?.description || "-",
    i.client?.name || "-",
    Number(i.expected.toFixed(2)),
    Number(i.received.toFixed(2)),
    Number(i.balance.toFixed(2)),
    i.status,
  ]);

  const cashflowRows = period.months.map((monthDate) => {
    const month = toMonthValue(monthDate);
    const inflow = payments
      .filter((p) => toMonthValue(parseDate(p.paymentDate)) === month)
      .reduce((s, p) => s + Number(p.totalAmount || 0), 0);
    const outflow = expenses
      .filter((e) => toMonthValue(parseDate(e.expenseDate)) === month)
      .reduce((s, e) => s + Number(e.amount || 0), 0);
    return [formatMonth(monthDate), Number(inflow.toFixed(2)), Number(outflow.toFixed(2)), Number((inflow - outflow).toFixed(2))];
  });

  const expenseCatRows = Object.entries(
    expenses.reduce((g, e) => {
      const k = e.expenseType || "Outros";
      g[k] = (g[k] || 0) + Number(e.amount || 0);
      return g;
    }, {}),
  )
    .map(([cat, amt]) => [cat, Number(amt.toFixed(2)), expensesTotal ? Number(((amt / expensesTotal) * 100).toFixed(2)) : 0])
    .sort((a, b) => b[1] - a[1]);

  const propRows = state.properties
    .map((property) => {
      const revenue = payments
        .filter((p) => p.propertyId === property.id)
        .reduce((s, p) => s + Number(p.totalAmount || 0), 0);
      const expTotal = expenses
        .filter((e) => e.propertyId === property.id)
        .reduce((s, e) => s + Number(e.amount || 0), 0);
      const result = revenue - expTotal;
      const margin = revenue ? (result / revenue) * 100 : 0;
      const roi = calculatePropertyRoi(property, result, period.months.length);
      return [
        property.description,
        Number(revenue.toFixed(2)),
        Number(expTotal.toFixed(2)),
        Number(result.toFixed(2)),
        Number(margin.toFixed(2)),
        Number(roi.annual.toFixed(2)),
        Number(roi.total.toFixed(2)),
      ];
    })
    .filter((r) => r[1] || r[2] || r[3]);

  return {
    period,
    summary,
    receivables: { headers: ["Vencimento", "Imovel", "Cliente", "Previsto", "Recebido", "Saldo", "Status"], rows: receivablesRows },
    cashflow: { headers: ["Mes", "Entradas", "Saidas", "Saldo"], rows: cashflowRows },
    expenseCategories: { headers: ["Categoria", "Total", "Participacao %"], rows: expenseCatRows },
    profitability: {
      headers: ["Imovel", "Receita", "Despesas", "Resultado", "Margem %", "ROI anualizado %", "ROI total %"],
      rows: propRows,
    },
  };
}

function exportFinancialErpExcel() {
  const data = getErpExportData();
  const fileName = `erp-financeiro-${toMonthValue(data.period.startDate)}_a_${toMonthValue(data.period.endDate)}.xlsx`;

  if (typeof XLSX === "undefined") {
    alert("Biblioteca XLSX nao carregou. Verifique sua conexao para gerar o arquivo Excel.");
    return;
  }
  const wb = XLSX.utils.book_new();
  const addSheet = (name, headers, rows, prefix = []) => {
    const aoa = [...prefix];
    if (headers) aoa.push(headers);
    aoa.push(...rows);
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    XLSX.utils.book_append_sheet(wb, ws, name.slice(0, 31));
  };
  addSheet("Resumo", null, data.summary, [[`ERP Financeiro - ${companyName}`], [`Gerado em ${formatDate(toIsoDate(new Date()))}`], []]);
  addSheet("Contas a receber", data.receivables.headers, data.receivables.rows);
  addSheet("Fluxo de caixa", data.cashflow.headers, data.cashflow.rows);
  addSheet("Despesas por categoria", data.expenseCategories.headers, data.expenseCategories.rows);
  addSheet("Rentabilidade por imovel", data.profitability.headers, data.profitability.rows);
  XLSX.writeFile(wb, fileName);
}

function exportFinancialErpPdf() {
  const data = getErpExportData();
  const fileName = `erp-financeiro-${toMonthValue(data.period.startDate)}_a_${toMonthValue(data.period.endDate)}.pdf`;

  const jsPDFCtor = window.jspdf?.jsPDF;
  if (!jsPDFCtor) {
    alert("Biblioteca jsPDF nao carregou. Verifique sua conexao para gerar o PDF.");
    return;
  }
  const doc = new jsPDFCtor({ unit: "pt", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  doc.setFontSize(16);
  doc.text(`ERP Financeiro - ${companyName}`, 40, 50);
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(
    `Periodo: ${formatMonth(data.period.startDate)} a ${formatMonth(data.period.endDate)}    -    Gerado em ${formatDate(toIsoDate(new Date()))}`,
    40,
    68,
  );
  doc.setTextColor(0);

  const drawTable = (title, headers, rows) => {
    if (typeof doc.autoTable !== "function") {
      doc.setFontSize(12);
      doc.text(title, 40, doc.lastAutoTable?.finalY ? doc.lastAutoTable.finalY + 30 : 100);
      return;
    }
    doc.autoTable({
      head: headers ? [headers] : undefined,
      body: rows.map((r) => r.map((c) => (typeof c === "number" ? formatMoneyOrNumber(c) : String(c)))),
      startY: doc.lastAutoTable?.finalY ? doc.lastAutoTable.finalY + 24 : 90,
      margin: { left: 40, right: 40 },
      styles: { fontSize: 8, cellPadding: 3, overflow: "linebreak", minCellHeight: 12 },
      headStyles: { fillColor: [92, 23, 27], textColor: 255 },
      didDrawPage: () => {
        doc.setFontSize(11);
        doc.setTextColor(92, 23, 27);
        doc.text(title, 40, doc.lastAutoTable?.finalY ? 40 : 86);
        doc.setTextColor(0);
      },
    });
  };

  // Resumo como tabela simples
  if (typeof doc.autoTable === "function") {
    doc.autoTable({
      body: data.summary,
      startY: 90,
      margin: { left: 40, right: 40 },
      styles: { fontSize: 9, cellPadding: 4, overflow: "linebreak" },
      columnStyles: { 0: { fontStyle: "bold", cellWidth: 200 } },
    });
  }
  drawTable("Contas a receber", data.receivables.headers, data.receivables.rows);
  drawTable("Fluxo de caixa", data.cashflow.headers, data.cashflow.rows);
  drawTable("Despesas por categoria", data.expenseCategories.headers, data.expenseCategories.rows);
  drawTable("Rentabilidade por imovel", data.profitability.headers, data.profitability.rows);

  doc.save(fileName);
}

function formatMoneyOrNumber(value) {
  if (Number.isFinite(value)) return formatMoney(value);
  return String(value);
}

function exportFinancialErpCsv() {
  const data = getErpExportData();
  const lines = [];
  const push = (title, headers, rows) => {
    lines.push(title);
    if (headers) lines.push(headers.join(";"));
    rows.forEach((r) => lines.push(r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")));
    lines.push("");
  };
  push("Resumo", null, data.summary);
  push("Contas a receber", data.receivables.headers, data.receivables.rows);
  push("Fluxo de caixa", data.cashflow.headers, data.cashflow.rows);
  push("Despesas por categoria", data.expenseCategories.headers, data.expenseCategories.rows);
  push("Rentabilidade por imovel", data.profitability.headers, data.profitability.rows);
  downloadTextFile(
    "\ufeff" + lines.join("\n"),
    `erp-financeiro-${toMonthValue(data.period.startDate)}_a_${toMonthValue(data.period.endDate)}.csv`,
    "text/csv;charset=utf-8",
  );
}
